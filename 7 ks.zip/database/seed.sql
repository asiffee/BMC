-- Safe starting data: roles, permissions, default website settings. No personal data.
USE bandhan_marriage_consultant;

INSERT IGNORE INTO roles (id, name, description) VALUES
 (1,'admin','Full authorized access'),
 (2,'matchmaker','Manages own or assigned profiles'),
 (3,'user','Manages own profile and browses approved profiles');

INSERT IGNORE INTO permissions (id, code, description) VALUES
 (1,'profiles.view_all','View every profile including private data'),
 (2,'profiles.edit_any','Edit any profile'),
 (3,'profiles.approve','Approve, reject, suspend or archive profiles'),
 (4,'profiles.create','Create matrimonial profiles'),
 (5,'profiles.edit_assigned','Edit assigned profiles'),
 (6,'profiles.edit_own','Edit own profile'),
 (7,'matchmakers.manage','Create and manage matchmakers'),
 (8,'settings.manage','Manage website settings'),
 (9,'audit.view','View audit logs'),
 (10,'contact.view_private','View private contact numbers and addresses (own/authorized)');

INSERT IGNORE INTO role_permissions (role_id, permission_id) VALUES
 (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),
 (2,4),(2,5),(2,6),(2,10),
 (3,4),(3,6),(3,10);

-- Contact details are left empty on purpose: the administrator enters real ones in Admin > Settings.
INSERT IGNORE INTO website_settings (setting_key, setting_value) VALUES
 ('contact_person','Asif Javed'),
 ('contact_phone',''),('contact_whatsapp',''),('contact_email',''),
 ('office_address',''),('business_hours',''),
 ('hero_title','Find Your Perfect Life Partner'),
 ('hero_text','Bandhan Marriage Consultant connects families through trusted, private and professional matchmaking.'),
 ('carousel','[]');
