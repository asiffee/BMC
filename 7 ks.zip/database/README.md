# Database - bandhan_marriage_consultant

Files
- `schema.sql` - complete schema (28 tables, foreign keys, indexes, constraints). Safe to re-run (`IF NOT EXISTS`).
- `seed.sql` - roles, permissions and default website settings. No personal data.
- `migrations/001_initial_schema.sql` - versioned copy of the first schema. Add future changes as `002_...sql`, `003_...sql`.

## Create it (Windows, MySQL 8)
In PowerShell from the project folder (type only the command, not the `PS D:\...>` prompt):

    mysql -u root -p < database\schema.sql
    mysql -u root -p < database\seed.sql

Or open both files in MySQL Workbench and run them in order (lightning icon).

## Create a limited app user (do not run the website as root)
    CREATE USER 'bandhan_app'@'localhost' IDENTIFIED BY 'choose-a-strong-password';
    GRANT SELECT, INSERT, UPDATE, DELETE ON bandhan_marriage_consultant.* TO 'bandhan_app'@'localhost';
    FLUSH PRIVILEGES;
Put these values in `.env` (`DB_USER`, `DB_PASSWORD`).

## Backup and restore
Backup: `powershell -ExecutionPolicy Bypass -File scripts\backup-db.ps1`
Restore: `mysql -u root -p bandhan_marriage_consultant < backups\bandhan-YYYYMMDD-HHMM.sql`
Also copy `storage\private\` (uploaded photographs) - it is not inside the database.

## Where private data lives
Addresses, contacts, income/employment, family details, internal notes and verification documents are in
separate tables from `profiles`. Only the `public_*` columns of `profiles` are ever shown to the public.
