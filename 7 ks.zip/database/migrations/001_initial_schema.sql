-- Bandhan Marriage Consultant - complete schema (MySQL 8 / MariaDB 10.5+)
CREATE DATABASE IF NOT EXISTS bandhan_marriage_consultant
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bandhan_marriage_consultant;

SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NULL UNIQUE,
  phone VARCHAR(30) NULL UNIQUE,
  password_hash VARCHAR(100) NOT NULL,
  status ENUM('active','suspended','deactivated','deletion_requested') NOT NULL DEFAULT 'active',
  email_verified_at DATETIME NULL,
  phone_verified_at DATETIME NULL,
  accepted_terms_at DATETIME NULL,
  failed_logins INT NOT NULL DEFAULT 0,
  locked_until DATETIME NULL,
  last_login_at DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT chk_user_contact CHECK (email IS NOT NULL OR phone IS NOT NULL)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS roles (
  id SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(40) NOT NULL UNIQUE,
  description VARCHAR(255) NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS permissions (
  id SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(80) NOT NULL UNIQUE,
  description VARCHAR(255) NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS role_permissions (
  role_id SMALLINT UNSIGNED NOT NULL,
  permission_id SMALLINT UNSIGNED NOT NULL,
  PRIMARY KEY (role_id, permission_id),
  FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
  FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS user_roles (
  user_id BIGINT UNSIGNED NOT NULL,
  role_id SMALLINT UNSIGNED NOT NULL,
  PRIMARY KEY (user_id, role_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS matchmakers (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL UNIQUE,
  business_name VARCHAR(150) NULL,
  status ENUM('pending','approved','suspended') NOT NULL DEFAULT 'pending',
  approved_by BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Core profile. Only the explicit public_* columns may ever be shown publicly.
CREATE TABLE IF NOT EXISTS profiles (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  owner_user_id BIGINT UNSIGNED NULL,
  created_by_user_id BIGINT UNSIGNED NOT NULL,
  gender ENUM('male','female') NOT NULL,
  full_name VARCHAR(120) NOT NULL,
  display_name VARCHAR(60) NOT NULL,
  date_of_birth DATE NOT NULL,
  marital_status ENUM('never_married','divorced','widowed','other') NOT NULL DEFAULT 'never_married',
  previous_marriages TINYINT UNSIGNED NULL,
  children_count TINYINT UNSIGNED NULL,
  nationality VARCHAR(60) NULL,
  religion VARCHAR(60) NULL,
  sect VARCHAR(60) NULL,
  caste_biradari VARCHAR(80) NULL,
  mother_tongue VARCHAR(60) NULL,
  other_languages VARCHAR(190) NULL,
  blood_group VARCHAR(5) NULL,
  height_cm SMALLINT UNSIGNED NULL,
  weight_kg SMALLINT UNSIGNED NULL,
  physical_description VARCHAR(500) NULL,
  disability_info VARCHAR(500) NULL,
  introduction TEXT NULL,
  hobbies VARCHAR(500) NULL,
  public_city VARCHAR(80) NULL,
  public_education VARCHAR(120) NULL,
  public_occupation VARCHAR(120) NULL,
  public_bio VARCHAR(600) NULL,
  visibility ENUM('public','members','private') NOT NULL DEFAULT 'public',
  approval_status ENUM('draft','pending','approved','rejected','suspended','archived') NOT NULL DEFAULT 'draft',
  verification_status ENUM('unverified','pending','verified','rejected') NOT NULL DEFAULT 'unverified',
  reviewed_by BIGINT UNSIGNED NULL,
  reviewed_at DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (owner_user_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (created_by_user_id) REFERENCES users(id),
  FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_prof_status (approval_status, visibility),
  INDEX idx_prof_gender_dob (gender, date_of_birth),
  INDEX idx_prof_city (public_city),
  INDEX idx_prof_owner (owner_user_id),
  INDEX idx_prof_creator (created_by_user_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS profile_addresses (
  profile_id BIGINT UNSIGNED PRIMARY KEY,
  country VARCHAR(60), province VARCHAR(60), division VARCHAR(60), district VARCHAR(60),
  tehsil VARCHAR(60), city VARCHAR(60), town_village VARCHAR(80), union_council VARCHAR(80),
  locality VARCHAR(100), street VARCHAR(120), house_number VARCHAR(30), postal_code VARCHAR(15),
  permanent_address VARCHAR(300), current_address VARCHAR(300),
  residential_status ENUM('owned','rented','family_home','other') NULL,
  preferred_marriage_location VARCHAR(120) NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS profile_contacts (
  profile_id BIGINT UNSIGNED PRIMARY KEY,
  primary_phone VARCHAR(30), whatsapp VARCHAR(30), secondary_phone VARCHAR(30),
  email VARCHAR(190), guardian_phone VARCHAR(30),
  preferred_contact_method ENUM('phone','whatsapp','email') NULL,
  contact_person VARCHAR(120) NULL,
  accepts_inquiries TINYINT(1) NOT NULL DEFAULT 0,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS profile_education (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  profile_id BIGINT UNSIGNED NOT NULL,
  level VARCHAR(60) NOT NULL,
  degree_title VARCHAR(120) NULL, field_of_study VARCHAR(120) NULL,
  institution VARCHAR(150) NULL, graduation_year SMALLINT UNSIGNED NULL,
  is_highest TINYINT(1) NOT NULL DEFAULT 0,
  notes VARCHAR(300) NULL,
  FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE,
  INDEX idx_edu_profile (profile_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS profile_employment (
  profile_id BIGINT UNSIGNED PRIMARY KEY,
  employment_status VARCHAR(40), occupation VARCHAR(120), job_title VARCHAR(120),
  job_nature ENUM('government','private','semi_government','ngo','self_employed','freelancer','other') NULL,
  department VARCHAR(120), organization VARCHAR(150), industry VARCHAR(100),
  designation VARCHAR(100), pay_scale VARCHAR(30),
  service_years DECIMAL(4,1) NULL, experience_years DECIMAL(4,1) NULL,
  workplace_city VARCHAR(80), job_location VARCHAR(150), employment_country VARCHAR(60),
  employment_type ENUM('permanent','contract','temporary','part_time') NULL,
  business_name VARCHAR(150), business_type VARCHAR(100), business_location VARCHAR(150), business_ownership VARCHAR(60),
  monthly_income_range VARCHAR(40), annual_income_range VARCHAR(40),
  additional_income VARCHAR(200), career_plans VARCHAR(400),
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS profile_family (
  profile_id BIGINT UNSIGNED PRIMARY KEY,
  father_name VARCHAR(120), father_occupation VARCHAR(120), father_employment_status VARCHAR(40),
  mother_name VARCHAR(120), mother_occupation VARCHAR(120),
  brothers_total TINYINT UNSIGNED, brothers_married TINYINT UNSIGNED, brothers_unmarried TINYINT UNSIGNED,
  sisters_total TINYINT UNSIGNED, sisters_married TINYINT UNSIGNED, sisters_unmarried TINYINT UNSIGNED,
  family_type ENUM('joint','nuclear') NULL,
  family_values VARCHAR(300), financial_background VARCHAR(200), family_introduction TEXT NULL,
  guardian_name VARCHAR(120), guardian_relationship VARCHAR(60), family_expectations VARCHAR(400),
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS partner_preferences (
  profile_id BIGINT UNSIGNED PRIMARY KEY,
  age_min TINYINT UNSIGNED, age_max TINYINT UNSIGNED, height_min_cm SMALLINT UNSIGNED, height_max_cm SMALLINT UNSIGNED,
  marital_status VARCHAR(60), education VARCHAR(120), profession VARCHAR(120), employment_type VARCHAR(40),
  income_range VARCHAR(40), city_region VARCHAR(120), country VARCHAR(60), caste_biradari VARCHAR(80),
  language VARCHAR(60), religious_preference VARCHAR(120), family_preference VARCHAR(200),
  lifestyle VARCHAR(200), relocation VARCHAR(60), marriage_timeline VARCHAR(60), other_expectations VARCHAR(500),
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Files live in protected storage; only the key is stored here.
CREATE TABLE IF NOT EXISTS profile_photos (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  profile_id BIGINT UNSIGNED NOT NULL,
  storage_key VARCHAR(120) NOT NULL UNIQUE,
  mime_type VARCHAR(40) NOT NULL,
  size_bytes INT UNSIGNED NOT NULL,
  is_main TINYINT(1) NOT NULL DEFAULT 0,
  uploaded_by BIGINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE,
  FOREIGN KEY (uploaded_by) REFERENCES users(id),
  INDEX idx_photo_profile (profile_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS profile_verifications (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  profile_id BIGINT UNSIGNED NOT NULL,
  doc_type ENUM('identity','education','employment','other') NOT NULL,
  storage_key VARCHAR(120) NULL,
  mime_type VARCHAR(40) NULL,
  status ENUM('pending','verified','rejected') NOT NULL DEFAULT 'pending',
  reviewed_by BIGINT UNSIGNED NULL,
  reviewed_at DATETIME NULL,
  note VARCHAR(300) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE,
  FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS profile_consents (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  profile_id BIGINT UNSIGNED NOT NULL,
  consent_type ENUM('data_collection','public_display','share_contact','share_photos') NOT NULL,
  granted TINYINT(1) NOT NULL,
  granted_by BIGINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE,
  FOREIGN KEY (granted_by) REFERENCES users(id),
  INDEX idx_consent (profile_id, consent_type, created_at)
) ENGINE=InnoDB;

-- Internal notes are kept apart so they can never leak with profile data.
CREATE TABLE IF NOT EXISTS profile_internal_notes (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  profile_id BIGINT UNSIGNED NOT NULL,
  author_user_id BIGINT UNSIGNED NOT NULL,
  note_type ENUM('admin','matchmaker') NOT NULL,
  note TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE,
  FOREIGN KEY (author_user_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS matchmaker_profile_assignments (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  matchmaker_id BIGINT UNSIGNED NOT NULL,
  profile_id BIGINT UNSIGNED NOT NULL,
  can_edit TINYINT(1) NOT NULL DEFAULT 1,
  can_view_contact TINYINT(1) NOT NULL DEFAULT 0,
  assigned_by BIGINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_assignment (matchmaker_id, profile_id),
  FOREIGN KEY (matchmaker_id) REFERENCES matchmakers(id) ON DELETE CASCADE,
  FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE,
  FOREIGN KEY (assigned_by) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS profile_favorites (
  user_id BIGINT UNSIGNED NOT NULL,
  profile_id BIGINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, profile_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS contact_requests (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  from_user_id BIGINT UNSIGNED NOT NULL,
  from_profile_id BIGINT UNSIGNED NULL,
  to_profile_id BIGINT UNSIGNED NOT NULL,
  message VARCHAR(500) NULL,
  status ENUM('pending','accepted','declined','cancelled') NOT NULL DEFAULT 'pending',
  responded_at DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_request (from_user_id, to_profile_id),
  FOREIGN KEY (from_user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (from_profile_id) REFERENCES profiles(id) ON DELETE SET NULL,
  FOREIGN KEY (to_profile_id) REFERENCES profiles(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS match_introductions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  profile_a_id BIGINT UNSIGNED NOT NULL,
  profile_b_id BIGINT UNSIGNED NOT NULL,
  introduced_by BIGINT UNSIGNED NOT NULL,
  contact_request_id BIGINT UNSIGNED NULL,
  status ENUM('proposed','accepted','declined','met','engaged','married','closed') NOT NULL DEFAULT 'proposed',
  note VARCHAR(400) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_pair (profile_a_id, profile_b_id),
  FOREIGN KEY (profile_a_id) REFERENCES profiles(id) ON DELETE CASCADE,
  FOREIGN KEY (profile_b_id) REFERENCES profiles(id) ON DELETE CASCADE,
  FOREIGN KEY (introduced_by) REFERENCES users(id),
  FOREIGN KEY (contact_request_id) REFERENCES contact_requests(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS messages (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  contact_request_id BIGINT UNSIGNED NOT NULL,
  sender_user_id BIGINT UNSIGNED NOT NULL,
  body VARCHAR(1000) NOT NULL,
  read_at DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (contact_request_id) REFERENCES contact_requests(id) ON DELETE CASCADE,
  FOREIGN KEY (sender_user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS contact_inquiries (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(120) NOT NULL,
  email_or_phone VARCHAR(190) NOT NULL,
  subject VARCHAR(150) NOT NULL,
  message TEXT NOT NULL,
  ip_hash CHAR(64) NULL,
  status ENUM('new','read','answered','spam') NOT NULL DEFAULT 'new',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS notifications (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  type VARCHAR(40) NOT NULL,
  title VARCHAR(150) NOT NULL,
  body VARCHAR(400) NULL,
  read_at DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_notif_user (user_id, read_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS abuse_reports (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reporter_user_id BIGINT UNSIGNED NOT NULL,
  profile_id BIGINT UNSIGNED NOT NULL,
  reason VARCHAR(400) NOT NULL,
  status ENUM('open','reviewed','dismissed') NOT NULL DEFAULT 'open',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (reporter_user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL UNIQUE,
  expires_at DATETIME NOT NULL,
  used_at DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  actor_user_id BIGINT UNSIGNED NULL,
  action VARCHAR(60) NOT NULL,
  entity_type VARCHAR(40) NULL,
  entity_id BIGINT UNSIGNED NULL,
  detail VARCHAR(500) NULL,
  ip_hash CHAR(64) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (actor_user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_audit_actor (actor_user_id, created_at),
  INDEX idx_audit_entity (entity_type, entity_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS website_settings (
  setting_key VARCHAR(80) PRIMARY KEY,
  setting_value TEXT NULL,
  updated_by BIGINT UNSIGNED NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;
