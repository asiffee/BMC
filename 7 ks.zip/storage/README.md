# storage
`storage/private/` holds uploaded photographs and verification documents.
It is created automatically, is never served as static files, and is excluded from git.
Files are only streamed by the API after an authorization check (`GET /api/photos/:id`).
