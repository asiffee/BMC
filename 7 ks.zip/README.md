# Bandhan Marriage Consultant

Status of this delivery
- DONE and tested: MySQL schema, seed, backend API (authentication, role-based access, profile privacy, matchmaker isolation,
  protected photo storage, contact requests, admin tools, audit log, CSV export).
- NOT built yet: the React frontend (public pages, carousel, navbar with developer branding, the four panels' screens).
  It is the next stage and will call this API.

## Requirements (Windows)
Node.js 20 or newer, MySQL 8 (MySQL Workbench optional), VS Code.

## Setup
1. Extract this folder to `D:\BandhanMarriageConsultant`.
2. Create the database: see `database\README.md`.
3. Copy `.env.example` to `.env` and fill it in (database user/password, JWT_SECRET, ADMIN_EMAIL, ADMIN_PASSWORD).
   Generate a secret:  node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
4. In VS Code terminal:

       cd D:\BandhanMarriageConsultant\backend
       npm install
       npm run create-admin
       npm run dev

   Check http://localhost:5000/api/health

## Tests
They create and drop a separate database named `bandhan_test`, so use an account that may do that:

    cd D:\BandhanMarriageConsultant\backend
    $env:DB_USER="root"; $env:DB_PASSWORD="your-root-password"; npm test

## Security notes
- Passwords: bcrypt (bcryptjs, 12 rounds). Login lockout after 5 failures, IP rate limits.
- Sessions: JWT in an httpOnly SameSite cookie; roles are re-read from the database on every request.
- Private fields are removed on the server (never just hidden in the interface).
- Uploaded photos live in `storage\private`, are validated by file content, and are streamed only after an access check.
- No email service is connected yet: in development the password-reset link is printed in the server console.
- Before going live: HTTPS, `COOKIE_SECURE=true`, a strong `JWT_SECRET`, a limited DB user, regular backups.
