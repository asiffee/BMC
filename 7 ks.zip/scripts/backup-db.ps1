# Backup:  powershell -ExecutionPolicy Bypass -File scripts\backup-db.ps1
# Creates backups\bandhan-YYYYMMDD-HHMM.sql (also back up storage\private separately - it holds photographs).
New-Item -ItemType Directory -Force -Path "backups" | Out-Null
$file = "backups\bandhan-" + (Get-Date -Format "yyyyMMdd-HHmm") + ".sql"
& mysqldump -u root -p --single-transaction --routines bandhan_marriage_consultant | Out-File -Encoding utf8 $file
Write-Host "Saved $file"
