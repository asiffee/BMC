# Creates the database and loads roles/settings. Run from the project root in PowerShell:
#   powershell -ExecutionPolicy Bypass -File scripts\setup-db.ps1
$mysql = "mysql"
Write-Host "Enter your MySQL root password when asked (twice)."
Get-Content -Raw "database\schema.sql" | & $mysql -u root -p
Get-Content -Raw "database\seed.sql"   | & $mysql -u root -p
Write-Host "Done. Next: create the app user (see database\README.md) and copy .env.example to .env"
