process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = 'test-secret-test-secret-test-secret-1234567890';
process.env.DB_NAME = 'bandhan_test';
process.env.STORAGE_DIR = require('path').join(require('os').tmpdir(), 'bmc-test-storage');

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const request = require('supertest');

let app; let pool;
const PW = 'Passw0rd!x';
const H = { 'X-Requested-With': 'BMC' };
const PHONE = '0300-1234567';
const ADDRESS = '12 Secret Street Chakwal';

const profileBody = (over = {}) => ({
  consent: { data_collection: true },
  basic: { gender: 'male', full_name: 'Ali Raza Khan', display_name: 'Ali', date_of_birth: '1995-04-10', marital_status: 'never_married', public_city: 'Chakwal', public_education: 'MBA', public_occupation: 'Engineer', public_bio: 'Family oriented.', ...over },
  address: { city: 'Chakwal', permanent_address: ADDRESS },
  contact: { primary_phone: PHONE, email: 'private@example.com' },
  employment: { occupation: 'Engineer', monthly_income_range: '200k-300k' },
  family: { father_name: 'Private Father' },
  education: [{ level: 'Masters', degree_title: 'MBA', is_highest: true }],
  preferences: { age_min: 22, age_max: 30, city_region: 'Chakwal' },
});

async function login(identity) {
  const a = request.agent(app);
  const r = await a.post('/api/auth/login').set(H).send({ login: identity, password: PW });
  expect(r.status).toBe(200);
  return a;
}
const reg = (name, email, extra = {}) => request(app).post('/api/auth/register').set(H).send({ full_name: name, email, password: PW, confirm_password: PW, accept_terms: true, ...extra });

const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), crypto.randomBytes(64)]);

let admin; let userA; let userB; let mm1; let mm2; let ids = {};

beforeAll(async () => {
  const conn = await mysql.createConnection({ host: process.env.DB_HOST || 'localhost', user: process.env.DB_USER || 'root', password: process.env.DB_PASSWORD || '', multipleStatements: true });
  await conn.query('DROP DATABASE IF EXISTS bandhan_test');
  const dir = path.join(__dirname, '..', '..', 'database');
  for (const f of ['schema.sql', 'seed.sql']) {
    await conn.query(fs.readFileSync(path.join(dir, f), 'utf8').replace(/bandhan_marriage_consultant/g, 'bandhan_test'));
  }
  await conn.end();
  ({ pool } = require('../src/config/db'));
  app = require('../src/app');

  const hash = await bcrypt.hash(PW, 4);
  const [r] = await pool.query("INSERT INTO users (full_name, email, password_hash) VALUES ('Admin','admin@t.com',?)", [hash]);
  await pool.query("INSERT INTO user_roles (user_id, role_id) SELECT ?, id FROM roles WHERE name='admin'", [r.insertId]);
  admin = await login('admin@t.com');

  for (const [n, e] of [['User A', 'a@t.com'], ['User B', 'b@t.com']]) expect((await reg(n, e)).status).toBe(201);
  userA = await login('a@t.com'); userB = await login('b@t.com');
  for (const [n, e] of [['MM One', 'mm1@t.com'], ['MM Two', 'mm2@t.com']]) {
    expect((await admin.post('/api/admin/matchmakers').set(H).send({ full_name: n, email: e, password: PW })).status).toBe(201);
  }
  mm1 = await login('mm1@t.com'); mm2 = await login('mm2@t.com');
});

afterAll(async () => { await pool.end(); });

describe('authentication', () => {
  test('wrong password gives a generic error and unknown user gives the same error', async () => {
    const a = await request(app).post('/api/auth/login').set(H).send({ login: 'a@t.com', password: 'nope' });
    const b = await request(app).post('/api/auth/login').set(H).send({ login: 'nobody@t.com', password: 'nope' });
    expect(a.status).toBe(401); expect(b.status).toBe(401);
    expect(a.body.error).toBe(b.body.error);
  });
  test('private endpoints reject anonymous requests', async () => {
    expect((await request(app).get('/api/profiles')).status).toBe(401);
    expect((await request(app).get('/api/admin/dashboard')).status).toBe(401);
  });
  test('state-changing requests without the CSRF header are blocked', async () => {
    expect((await request(app).post('/api/auth/login').send({ login: 'a@t.com', password: PW })).status).toBe(403);
  });
  test('nobody can self-register as admin', async () => {
    expect((await reg('Evil', 'evil@t.com', { account_type: 'admin' })).status).toBe(400);
  });
  test('a self-registered matchmaker has no matchmaker powers until approved', async () => {
    expect((await reg('Pending MM', 'pmm@t.com', { account_type: 'matchmaker' })).status).toBe(201);
    const a = await login('pmm@t.com');
    expect((await a.get('/api/matchmaker/dashboard')).status).toBe(403);
    expect((await a.post('/api/profiles').set(H).send(profileBody())).status).toBe(201); // acts as an ordinary user only
  });
  test('password reset works once and tokens expire/are single use', async () => {
    const token = crypto.randomBytes(16).toString('hex');
    const [[u]] = await pool.query("SELECT id FROM users WHERE email='b@t.com'");
    await pool.query("INSERT INTO password_reset_tokens (user_id, token_hash, expires_at) VALUES (?,?,DATE_ADD(NOW(), INTERVAL 1 HOUR))", [u.id, crypto.createHash('sha256').update(token).digest('hex')]);
    expect((await request(app).post('/api/auth/reset-password').set(H).send({ token, password: 'NewPassw0rd1' })).status).toBe(200);
    expect((await request(app).post('/api/auth/reset-password').set(H).send({ token, password: 'Another1234x' })).status).toBe(400);
    expect((await request(app).post('/api/auth/login').set(H).send({ login: 'b@t.com', password: 'NewPassw0rd1' })).status).toBe(200);
    await pool.query('UPDATE users SET password_hash=? WHERE id=?', [await bcrypt.hash(PW, 4), u.id]);
  });
});

describe('profiles, approval and public privacy', () => {
  test('user creates a profile; it is not public until the admin approves it', async () => {
    const r = await userA.post('/api/profiles').set(H).send(profileBody());
    expect(r.status).toBe(201); ids.a = r.body.id;
    expect((await userA.post(`/api/profiles/${ids.a}/submit`).set(H)).status).toBe(200);
    const list = await request(app).get('/api/public/profiles');
    expect(list.body.items.find((x) => x.id === ids.a)).toBeUndefined();
    expect((await request(app).get(`/api/public/profiles/${ids.a}`)).status).toBe(404);
    expect((await admin.post(`/api/profiles/${ids.a}/review`).set(H).send({ action: 'approve' })).status).toBe(200);
  });
  test('approved public listing never contains private data', async () => {
    const r = await request(app).get('/api/public/profiles');
    const item = r.body.items.find((x) => x.id === ids.a);
    expect(item).toBeDefined();
    const text = JSON.stringify(r.body) + JSON.stringify((await request(app).get(`/api/public/profiles/${ids.a}`)).body);
    for (const secret of [PHONE, ADDRESS, 'private@example.com', 'Ali Raza Khan', '1995-04-10', 'Private Father', '200k-300k']) expect(text).not.toContain(secret);
    expect(Object.keys(item).sort()).toEqual(['age', 'bio', 'city', 'code', 'displayName', 'education', 'gender', 'id', 'occupation', 'verified'].sort());
  });
  test('SQL injection in filters is harmless', async () => {
    const r = await request(app).get("/api/public/profiles").query({ city: "' OR 1=1 --", education: "x'; DROP TABLE profiles;--" });
    expect(r.status).toBe(200); expect(r.body.items.length).toBe(0);
    expect((await request(app).get('/api/public/stats')).status).toBe(200);
  });
  test('another user sees only the public card of a profile and cannot edit it', async () => {
    const r = await userB.get(`/api/profiles/${ids.a}`);
    expect(r.status).toBe(200); expect(r.body.access).toBe('public');
    const text = JSON.stringify(r.body);
    for (const secret of [PHONE, ADDRESS, 'private@example.com', 'Ali Raza Khan']) expect(text).not.toContain(secret);
    expect((await userB.put(`/api/profiles/${ids.a}`).set(H).send({ basic: { display_name: 'Hacked' } })).status).toBe(404);
    expect((await userB.post(`/api/profiles/${ids.a}/photos`).set(H).attach('photo', png, 'x.png')).status).toBe(404);
  });
  test('the owner sees everything of their own profile, admin too', async () => {
    const o = await userA.get(`/api/profiles/${ids.a}`);
    expect(o.body.contact.primary_phone).toBe(PHONE); expect(o.body.address.permanent_address).toBe(ADDRESS);
    const a = await admin.get(`/api/profiles/${ids.a}`);
    expect(a.body.contact.primary_phone).toBe(PHONE); expect(a.body.employment.monthly_income_range).toBe('200k-300k');
  });
  test('mass-assignment is ignored (cannot self-approve or take ownership)', async () => {
    await userA.put(`/api/profiles/${ids.a}`).set(H).send({ basic: { approval_status: 'approved', verification_status: 'verified', owner_user_id: 1, display_name: 'Ali R' } });
    const [[p]] = await pool.query('SELECT approval_status, verification_status, owner_user_id, display_name FROM profiles WHERE id=?', [ids.a]);
    expect(p.approval_status).toBe('pending'); // owner edit of an approved profile returns it to review
    expect(p.verification_status).toBe('unverified'); expect(p.owner_user_id).not.toBe(1); expect(p.display_name).toBe('Ali R');
    await admin.post(`/api/profiles/${ids.a}/review`).set(H).send({ action: 'approve' });
  });
  test('validation errors are reported per field', async () => {
    const r = await userB.post('/api/profiles').set(H).send(profileBody({ date_of_birth: '2020-01-01', gender: 'x' }));
    expect(r.status).toBe(400); expect(r.body.fields.gender).toBeDefined(); expect(r.body.fields.date_of_birth).toBeDefined();
  });
});

describe('matchmaker isolation', () => {
  test('matchmaker creates a profile and is the only matchmaker with access', async () => {
    const r = await mm1.post('/api/profiles').set(H).send(profileBody({ full_name: 'Sara Private', display_name: 'Sara', gender: 'female' }));
    expect(r.status).toBe(201); ids.m1 = r.body.id;
    await mm1.post(`/api/profiles/${ids.m1}/submit`).set(H);
    await admin.post(`/api/profiles/${ids.m1}/review`).set(H).send({ action: 'approve' });
    const own = await mm1.get(`/api/profiles/${ids.m1}`);
    expect(own.body.contact.primary_phone).toBe(PHONE);
    // even though the profile is approved and public, mm2 gets the card only
    const other = await mm2.get(`/api/profiles/${ids.m1}`);
    expect(other.body.access).toBe('public');
    const text = JSON.stringify(other.body);
    for (const secret of [PHONE, ADDRESS, 'Sara Private', 'private@example.com']) expect(text).not.toContain(secret);
  });
  test('mm2 cannot edit, photograph, annotate or list mm1 records by changing the ID', async () => {
    expect((await mm2.put(`/api/profiles/${ids.m1}`).set(H).send({ basic: { display_name: 'X' } })).status).toBe(404);
    expect((await mm2.post(`/api/profiles/${ids.m1}/notes`).set(H).send({ note: 'x' })).status).toBe(404);
    expect((await mm2.post(`/api/profiles/${ids.m1}/photos`).set(H).attach('photo', png, 'a.png')).status).toBe(404);
    const l1 = await mm1.get('/api/profiles'); const l2 = await mm2.get('/api/profiles');
    expect(l1.body.items.map((x) => x.id)).toContain(ids.m1);
    expect(l2.body.items.map((x) => x.id)).not.toContain(ids.m1);
    expect((await mm2.get(`/api/profiles/${ids.m1}/compatible`)).status).toBe(404);
  });
  test('assignment grants view/edit but contact access only when explicitly allowed', async () => {
    const [[m2]] = await pool.query("SELECT m.id FROM matchmakers m JOIN users u ON u.id=m.user_id WHERE u.email='mm2@t.com'");
    expect((await admin.post(`/api/profiles/${ids.m1}/assign`).set(H).send({ matchmaker_id: m2.id, can_edit: true, can_view_contact: false })).status).toBe(200);
    const v = await mm2.get(`/api/profiles/${ids.m1}`);
    expect(v.body.access).toBe('assigned'); expect(v.body.contact).toBeUndefined(); expect(v.body.address).toBeUndefined();
    expect((await mm2.put(`/api/profiles/${ids.m1}`).set(H).send({ contact: { primary_phone: '0999' } })).status).toBe(200);
    const [[c]] = await pool.query('SELECT primary_phone FROM profile_contacts WHERE profile_id=?', [ids.m1]);
    expect(c.primary_phone).toBe(PHONE); // contact section was silently refused
    await admin.post(`/api/profiles/${ids.m1}/assign`).set(H).send({ matchmaker_id: m2.id, can_edit: true, can_view_contact: true });
    expect((await mm2.get(`/api/profiles/${ids.m1}`)).body.contact.primary_phone).toBe(PHONE);
    await admin.delete(`/api/profiles/${ids.m1}/assign/${m2.id}`).set(H);
    expect((await mm2.get(`/api/profiles/${ids.m1}`)).body.access).toBe('public');
  });
  test('matchmaker dashboard counts only own profiles', async () => {
    const d1 = await mm1.get('/api/matchmaker/dashboard'); const d2 = await mm2.get('/api/matchmaker/dashboard');
    expect(d1.body.profilesByStatus.reduce((s, x) => s + x.count, 0)).toBe(1);
    expect(d2.body.profilesByStatus.length).toBe(0);
  });
  test('non-admins cannot use admin endpoints', async () => {
    for (const ag of [userA, mm1]) {
      for (const url of ['/api/admin/dashboard', '/api/admin/users', '/api/admin/audit-logs', '/api/admin/settings', '/api/admin/export/profiles.csv']) expect((await ag.get(url)).status).toBe(403);
    }
    expect((await mm1.post(`/api/profiles/${ids.m1}/review`).set(H).send({ action: 'approve' })).status).toBe(403);
    expect((await userA.post('/api/admin/matchmakers').set(H).send({ full_name: 'x', email: 'x@x.com', password: PW })).status).toBe(403);
  });
});

describe('photographs', () => {
  test('upload validates real file content and serves only to authorized users', async () => {
    const bad = await userA.post(`/api/profiles/${ids.a}/photos`).set(H).attach('photo', Buffer.from('<script>alert(1)</script>'), { filename: 'x.png', contentType: 'image/png' });
    expect(bad.status).toBe(400);
    const ok = await userA.post(`/api/profiles/${ids.a}/photos`).set(H).attach('photo', png, 'me.png');
    expect(ok.status).toBe(201);
    const photoId = ok.body.id;
    expect((await request(app).get(`/api/photos/${photoId}`)).status).toBe(401);
    expect((await userB.get(`/api/photos/${photoId}`)).status).toBe(404);
    expect((await mm1.get(`/api/photos/${photoId}`)).status).toBe(404);
    const mine = await userA.get(`/api/photos/${photoId}`);
    expect(mine.status).toBe(200); expect(mine.headers['content-type']).toContain('image/png');
    expect((await admin.get(`/api/photos/${photoId}`)).status).toBe(200);
    const view = await userA.get(`/api/profiles/${ids.a}`);
    expect(JSON.stringify(view.body)).not.toMatch(/storage_key|\.png/);
    expect((await userB.get(`/api/profiles/${ids.a}`)).body.photos).toBeUndefined();
  });
  test('uploaded files are not reachable as static files', async () => {
    const files = fs.readdirSync(path.join(process.env.STORAGE_DIR, 'photos'));
    expect((await request(app).get(`/photos/${files[0]}`)).status).toBe(404);
    expect((await request(app).get(`/storage/private/photos/${files[0]}`)).status).toBe(404);
  });
});

describe('contact requests, favorites, inquiries, admin', () => {
  test('contact-request workflow never reveals private contact data', async () => {
    const r = await userB.post('/api/contact-requests').set(H).send({ to_profile_id: ids.a, message: 'Hello' });
    expect(r.status).toBe(201);
    expect((await userB.post('/api/contact-requests').set(H).send({ to_profile_id: ids.a })).status).toBe(409);
    expect((await userA.post('/api/contact-requests').set(H).send({ to_profile_id: ids.a })).status).toBe(400);
    expect((await userB.put(`/api/contact-requests/${r.body.id}`).set(H).send({ status: 'accepted' })).status).toBe(404);
    const rec = await userA.get('/api/contact-requests');
    expect(rec.body.received.length).toBe(1);
    expect((await userA.put(`/api/contact-requests/${r.body.id}`).set(H).send({ status: 'accepted' })).status).toBe(200);
    const sent = await userB.get('/api/contact-requests');
    expect(JSON.stringify(sent.body)).not.toContain(PHONE);
    expect((await userB.get('/api/notifications')).body.items.length).toBeGreaterThan(0);
  });
  test('favorites work for approved profiles only', async () => {
    expect((await userB.post(`/api/favorites/${ids.a}`).set(H)).status).toBe(200);
    expect((await userB.get('/api/favorites')).body.items.length).toBe(1);
    expect((await userB.post('/api/favorites/999999').set(H)).status).toBe(404);
  });
  test('contact form stores valid messages, rejects invalid ones and ignores bots', async () => {
    const good = { full_name: 'Visitor', email_or_phone: 'v@example.com', subject: 'Question', message: 'I would like to know more please.' };
    expect((await request(app).post('/api/public/inquiries').set(H).send(good)).status).toBe(201);
    expect((await request(app).post('/api/public/inquiries').set(H).send({ ...good, message: 'short' })).status).toBe(400);
    await request(app).post('/api/public/inquiries').set(H).send({ ...good, website: 'http://spam' });
    const [[{ n }]] = await pool.query('SELECT COUNT(*) n FROM contact_inquiries');
    expect(n).toBe(1);
  });
  test('admin dashboard, audit log and CSV export work and are logged', async () => {
    const d = await admin.get('/api/admin/dashboard');
    expect(d.status).toBe(200); expect(d.body.counts.male).toBeGreaterThan(0);
    const csv = await admin.get('/api/admin/export/profiles.csv');
    expect(csv.status).toBe(200); expect(csv.text).toContain('Ali');
    const logs = await admin.get('/api/admin/audit-logs');
    expect(logs.body.items.map((x) => x.action)).toEqual(expect.arrayContaining(['profile_viewed_private', 'export_profiles', 'profile_approve']));
  });
  test('public settings expose only whitelisted keys', async () => {
    await admin.put('/api/admin/settings').set(H).send({ contact_phone: '+92 300 0000000', jwt_secret: 'x' });
    const r = await request(app).get('/api/public/settings');
    expect(r.body.contact_person).toBe('Asif Javed'); expect(r.body.contact_phone).toBe('+92 300 0000000'); expect(r.body.jwt_secret).toBeUndefined();
  });
  test('suspended users are locked out immediately', async () => {
    const [[u]] = await pool.query("SELECT id FROM users WHERE email='b@t.com'");
    await admin.patch(`/api/admin/users/${u.id}`).set(H).send({ status: 'suspended' });
    expect((await userB.get('/api/profiles/browse')).status).toBe(401);
  });
});
