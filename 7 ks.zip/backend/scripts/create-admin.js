// Creates the first administrator from .env (ADMIN_EMAIL / ADMIN_PASSWORD). Run: npm run create-admin
const bcrypt = require('bcryptjs');
const env = require('../src/config/env');
const { pool } = require('../src/config/db');
const { validatePassword } = require('../src/validators/schemas');

(async () => {
  const email = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  const name = process.env.ADMIN_NAME || 'Site Administrator';
  if (!email || !process.env.ADMIN_PASSWORD) { console.error('Set ADMIN_EMAIL and ADMIN_PASSWORD in .env first.'); process.exit(1); }
  validatePassword(process.env.ADMIN_PASSWORD);
  const [[ex]] = await pool.query('SELECT id FROM users WHERE email=?', [email]);
  if (ex) { console.log('An account with this email already exists. Nothing changed.'); process.exit(0); }
  const hash = await bcrypt.hash(process.env.ADMIN_PASSWORD, 12);
  const [r] = await pool.query('INSERT INTO users (full_name, email, password_hash, accepted_terms_at, email_verified_at) VALUES (?,?,?,NOW(),NOW())', [name, email, hash]);
  await pool.query("INSERT INTO user_roles (user_id, role_id) SELECT ?, id FROM roles WHERE name='admin'", [r.insertId]);
  console.log(`Administrator created: ${email}. You can now remove ADMIN_PASSWORD from .env.`);
  process.exit(0);
})().catch((e) => { console.error(e.message); process.exit(1); });
