// Whitelisted columns per table + validation. Anything not listed here is ignored
// (prevents mass-assignment such as setting approval_status or owner_user_id).
class ValidationError extends Error {
  constructor(fields) { super('Validation failed'); this.status = 400; this.fields = fields; }
}
const s = (max, req) => ({ t: 's', max, req });
const i = (min, max, req) => ({ t: 'i', min, max, req });
const n = (min, max) => ({ t: 'n', min, max });
const e = (vals, req) => ({ t: 'e', vals, req });
const d = (req) => ({ t: 'd', req });
const b = () => ({ t: 'b' });

const BASIC = {
  gender: e(['male', 'female'], true), full_name: s(120, true), display_name: s(60, true),
  date_of_birth: d(true), marital_status: e(['never_married', 'divorced', 'widowed', 'other']),
  previous_marriages: i(0, 10), children_count: i(0, 20), nationality: s(60), religion: s(60),
  sect: s(60), caste_biradari: s(80), mother_tongue: s(60), other_languages: s(190),
  blood_group: s(5), height_cm: i(100, 250), weight_kg: i(30, 250), physical_description: s(500),
  disability_info: s(500), introduction: s(4000), hobbies: s(500), public_city: s(80),
  public_education: s(120), public_occupation: s(120), public_bio: s(600),
  visibility: e(['public', 'members', 'private']),
};
const ADDRESS = {
  country: s(60), province: s(60), division: s(60), district: s(60), tehsil: s(60), city: s(60),
  town_village: s(80), union_council: s(80), locality: s(100), street: s(120), house_number: s(30),
  postal_code: s(15), permanent_address: s(300), current_address: s(300),
  residential_status: e(['owned', 'rented', 'family_home', 'other']), preferred_marriage_location: s(120),
};
const CONTACT = {
  primary_phone: s(30), whatsapp: s(30), secondary_phone: s(30), email: s(190), guardian_phone: s(30),
  preferred_contact_method: e(['phone', 'whatsapp', 'email']), contact_person: s(120), accepts_inquiries: b(),
};
const EMPLOYMENT = {
  employment_status: s(40), occupation: s(120), job_title: s(120),
  job_nature: e(['government', 'private', 'semi_government', 'ngo', 'self_employed', 'freelancer', 'other']),
  department: s(120), organization: s(150), industry: s(100), designation: s(100), pay_scale: s(30),
  service_years: n(0, 70), experience_years: n(0, 70), workplace_city: s(80), job_location: s(150),
  employment_country: s(60), employment_type: e(['permanent', 'contract', 'temporary', 'part_time']),
  business_name: s(150), business_type: s(100), business_location: s(150), business_ownership: s(60),
  monthly_income_range: s(40), annual_income_range: s(40), additional_income: s(200), career_plans: s(400),
};
const FAMILY = {
  father_name: s(120), father_occupation: s(120), father_employment_status: s(40), mother_name: s(120),
  mother_occupation: s(120), brothers_total: i(0, 30), brothers_married: i(0, 30), brothers_unmarried: i(0, 30),
  sisters_total: i(0, 30), sisters_married: i(0, 30), sisters_unmarried: i(0, 30),
  family_type: e(['joint', 'nuclear']), family_values: s(300), financial_background: s(200),
  family_introduction: s(3000), guardian_name: s(120), guardian_relationship: s(60), family_expectations: s(400),
};
const PREFS = {
  age_min: i(18, 90), age_max: i(18, 90), height_min_cm: i(100, 250), height_max_cm: i(100, 250),
  marital_status: s(60), education: s(120), profession: s(120), employment_type: s(40), income_range: s(40),
  city_region: s(120), country: s(60), caste_biradari: s(80), language: s(60), religious_preference: s(120),
  family_preference: s(200), lifestyle: s(200), relocation: s(60), marriage_timeline: s(60), other_expectations: s(500),
};
const EDUCATION_ROW = {
  level: s(60, true), degree_title: s(120), field_of_study: s(120), institution: s(150),
  graduation_year: i(1950, 2100), is_highest: b(), notes: s(300),
};

function check(rule, v) {
  switch (rule.t) {
    case 's': {
      if (typeof v !== 'string' && typeof v !== 'number') return ['Must be text'];
      const t = String(v).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim();
      return t.length > rule.max ? [`Maximum ${rule.max} characters`] : [null, t];
    }
    case 'i': {
      const x = Number(v);
      return !Number.isInteger(x) || x < rule.min || x > rule.max ? [`Must be a whole number ${rule.min}-${rule.max}`] : [null, x];
    }
    case 'n': {
      const x = Number(v);
      return Number.isNaN(x) || x < rule.min || x > rule.max ? [`Must be a number ${rule.min}-${rule.max}`] : [null, x];
    }
    case 'e': return rule.vals.includes(v) ? [null, v] : ['Invalid option'];
    case 'd': {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(String(v))) return ['Use YYYY-MM-DD'];
      const dt = new Date(`${v}T00:00:00Z`);
      return Number.isNaN(dt.getTime()) || dt.toISOString().slice(0, 10) !== v ? ['Invalid date'] : [null, v];
    }
    case 'b': return [null, v === true || v === 1 || v === '1' || v === 'true' ? 1 : 0];
    default: return ['Unsupported'];
  }
}

function clean(spec, data, { partial = false } = {}) {
  const out = {}; const errors = {};
  if (data !== undefined && (typeof data !== 'object' || data === null || Array.isArray(data))) {
    throw new ValidationError({ _: 'Invalid data' });
  }
  for (const [k, rule] of Object.entries(spec)) {
    const v = data ? data[k] : undefined;
    if (v === undefined) { if (!partial && rule.req) errors[k] = 'Required'; continue; }
    if (v === null || v === '') { if (rule.req) errors[k] = 'Required'; else out[k] = null; continue; }
    const [err, val] = check(rule, v);
    if (err) errors[k] = err; else out[k] = val;
  }
  if (Object.keys(errors).length) throw new ValidationError(errors);
  return out;
}

function ageFromDob(dob) {
  const t = new Date(); const b0 = new Date(`${dob}T00:00:00Z`);
  let a = t.getUTCFullYear() - b0.getUTCFullYear();
  const m = t.getUTCMonth() - b0.getUTCMonth();
  if (m < 0 || (m === 0 && t.getUTCDate() < b0.getUTCDate())) a--;
  return a;
}

function validatePassword(pw) {
  if (typeof pw !== 'string' || pw.length < 8 || pw.length > 72 || !/[A-Za-z]/.test(pw) || !/\d/.test(pw)) {
    throw new ValidationError({ password: 'Password must be 8-72 characters and contain letters and numbers' });
  }
}

module.exports = { ValidationError, clean, ageFromDob, validatePassword, BASIC, ADDRESS, CONTACT, EMPLOYMENT, FAMILY, PREFS, EDUCATION_ROW };
