const router = require('express').Router();
const rateLimit = require('express-rate-limit');
const { pool } = require('../config/db');
const { wrap } = require('../middleware/errors');
const { publicCard, getAccess } = require('../services/access');
const { ipHash } = require('../services/audit');
const { ValidationError } = require('../validators/schemas');

const testing = process.env.NODE_ENV === 'test';
const inquiryLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 5, skip: () => testing, message: { error: 'Too many messages. Please try later.' } });

// Only these settings are ever exposed publicly.
const PUBLIC_SETTINGS = ['contact_person', 'contact_phone', 'contact_whatsapp', 'contact_email', 'office_address', 'business_hours', 'hero_title', 'hero_text', 'carousel'];

function page(req) {
  const p = Math.max(1, parseInt(req.query.page, 10) || 1);
  const l = Math.min(50, Math.max(1, parseInt(req.query.limit, 10) || 12));
  return { p, l, off: (p - 1) * l };
}

// Shared search used by the public page and by the logged-in "Find matches" screen.
async function searchCards(req, includeMembers) {
  const { p, l, off } = page(req);
  const where = ["approval_status='approved'", includeMembers ? "visibility IN ('public','members')" : "visibility='public'"];
  const args = [];
  const q = req.query;
  if (['male', 'female'].includes(q.gender)) { where.push('gender=?'); args.push(q.gender); }
  if (q.min_age) { where.push('TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) >= ?'); args.push(parseInt(q.min_age, 10) || 18); }
  if (q.max_age) { where.push('TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) <= ?'); args.push(parseInt(q.max_age, 10) || 90); }
  if (q.city) { where.push('public_city LIKE ?'); args.push(`%${String(q.city).slice(0, 60)}%`); }
  if (q.education) { where.push('public_education LIKE ?'); args.push(`%${String(q.education).slice(0, 60)}%`); }
  if (q.occupation) { where.push('public_occupation LIKE ?'); args.push(`%${String(q.occupation).slice(0, 60)}%`); }
  if (q.marital_status) { where.push('marital_status=?'); args.push(String(q.marital_status)); }
  if (q.verified === 'true') where.push("verification_status='verified'");
  const w = where.join(' AND ');
  const [[{ total }]] = await pool.query(`SELECT COUNT(*) total FROM profiles WHERE ${w}`, args);
  const [rows] = await pool.query(`SELECT * FROM profiles WHERE ${w} ORDER BY (verification_status='verified') DESC, id DESC LIMIT ? OFFSET ?`, [...args, l, off]);
  return { items: rows.map(publicCard), page: p, limit: l, total };
}

router.get('/profiles', wrap(async (req, res) => res.json(await searchCards(req, false))));

router.get('/profiles/:id(\\d+)', wrap(async (req, res) => {
  const a = await getAccess(null, req.params.id);
  if (!a || !a.canViewPublic) return res.status(404).json({ error: 'Not found' });
  res.json(publicCard(a.profile));
}));

router.get('/stats', wrap(async (_req, res) => {
  const [[s]] = await pool.query(`SELECT
    SUM(approval_status='approved') AS profiles, SUM(approval_status='approved' AND gender='male') AS male,
    SUM(approval_status='approved' AND gender='female') AS female, SUM(verification_status='verified') AS verified FROM profiles`);
  const [[m]] = await pool.query("SELECT COUNT(*) AS matches FROM match_introductions WHERE status IN ('engaged','married')");
  res.json({ profiles: Number(s.profiles || 0), male: Number(s.male || 0), female: Number(s.female || 0), verified: Number(s.verified || 0), successfulMatches: m.matches });
}));

router.get('/settings', wrap(async (_req, res) => {
  const [rows] = await pool.query('SELECT setting_key k, setting_value v FROM website_settings WHERE setting_key IN (?)', [PUBLIC_SETTINGS]);
  const out = {};
  rows.forEach((r) => { out[r.k] = r.v; });
  res.json(out);
}));

router.post('/inquiries', inquiryLimiter, wrap(async (req, res) => {
  const b = req.body || {};
  if (b.website) return res.json({ ok: true }); // honeypot field: bots fill it, people never see it
  const f = {};
  const name = String(b.full_name || '').trim(); const contact = String(b.email_or_phone || '').trim();
  const subject = String(b.subject || '').trim(); const message = String(b.message || '').trim();
  if (name.length < 2 || name.length > 120) f.full_name = 'Enter your name';
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(contact) && !/^[0-9+\-\s]{7,20}$/.test(contact)) f.email_or_phone = 'Enter a valid email or phone number';
  if (subject.length < 3 || subject.length > 150) f.subject = 'Enter a subject';
  if (message.length < 10 || message.length > 3000) f.message = 'Message must be 10-3000 characters';
  if ((message.match(/https?:\/\//g) || []).length > 2) f.message = 'Too many links';
  if (Object.keys(f).length) throw new ValidationError(f);
  await pool.query('INSERT INTO contact_inquiries (full_name, email_or_phone, subject, message, ip_hash) VALUES (?,?,?,?,?)', [name, contact, subject, message, ipHash(req)]);
  res.status(201).json({ ok: true, message: 'Thank you. Your message has been received.' });
}));

module.exports = router;
module.exports.searchCards = searchCards;
