const router = require('express').Router();
const multer = require('multer');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const env = require('../config/env');
const { pool, tx } = require('../config/db');
const { wrap, HttpError } = require('../middleware/errors');
const { requireAuth, requireRole } = require('../middleware/auth');
const { getAccess, buildProfileView, listRow, publicCard } = require('../services/access');
const { createProfile, updateProfile } = require('../services/profileService');
const { audit, notify } = require('../services/audit');
const { searchCards } = require('./public');
const { ValidationError, ageFromDob } = require('../validators/schemas');

router.use(requireAuth);

const pageArgs = (req) => {
  const p = Math.max(1, parseInt(req.query.page, 10) || 1);
  const l = Math.min(50, Math.max(1, parseInt(req.query.limit, 10) || 15));
  return { p, l, off: (p - 1) * l };
};

// Logged-in browsing: approved profiles (public + members-only), cards only.
router.get('/browse', wrap(async (req, res) => res.json(await searchCards(req, true))));

// "My records" list, scoped on the server by role.
router.get('/', wrap(async (req, res) => {
  const { p, l, off } = pageArgs(req);
  const u = req.user;
  const where = []; const args = []; let from = 'profiles pr';
  if (u.isAdmin) { /* all */ } else if (u.isMatchmaker) {
    from = 'profiles pr JOIN matchmaker_profile_assignments mpa ON mpa.profile_id=pr.id AND mpa.matchmaker_id=?'; args.push(u.matchmakerId);
  } else { where.push('pr.owner_user_id=?'); args.push(u.id); }
  const q = req.query;
  if (['draft', 'pending', 'approved', 'rejected', 'suspended', 'archived'].includes(q.status)) { where.push('pr.approval_status=?'); args.push(q.status); }
  if (['male', 'female'].includes(q.gender)) { where.push('pr.gender=?'); args.push(q.gender); }
  if (q.city) { where.push('pr.public_city LIKE ?'); args.push(`%${String(q.city).slice(0, 60)}%`); }
  if (q.q) { where.push('(pr.full_name LIKE ? OR pr.display_name LIKE ?)'); args.push(`%${String(q.q).slice(0, 60)}%`, `%${String(q.q).slice(0, 60)}%`); }
  if (q.min_age) { where.push('TIMESTAMPDIFF(YEAR, pr.date_of_birth, CURDATE()) >= ?'); args.push(parseInt(q.min_age, 10) || 18); }
  if (q.max_age) { where.push('TIMESTAMPDIFF(YEAR, pr.date_of_birth, CURDATE()) <= ?'); args.push(parseInt(q.max_age, 10) || 90); }
  const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const [[{ total }]] = await pool.query(`SELECT COUNT(*) total FROM ${from} ${w}`, args);
  const [rows] = await pool.query(`SELECT pr.* FROM ${from} ${w} ORDER BY pr.id DESC LIMIT ? OFFSET ?`, [...args, l, off]);
  res.json({ items: rows.map(listRow), page: p, limit: l, total });
}));

router.post('/', wrap(async (req, res) => {
  const u = req.user;
  const body = req.body || {};
  if (!(body.consent && body.consent.data_collection === true)) throw new ValidationError({ consent: 'Consent to data collection is required' });
  if (!u.isAdmin && !u.isMatchmaker) {
    const [[have]] = await pool.query('SELECT id FROM profiles WHERE owner_user_id=?', [u.id]);
    if (have) throw new HttpError(409, 'You already have a profile');
  }
  const id = await tx(async (conn) => {
    const pid = await createProfile(conn, { creatorId: u.id, ownerId: (u.isAdmin || u.isMatchmaker) ? null : u.id, body });
    if (u.isMatchmaker && !u.isAdmin) {
      await conn.query('INSERT INTO matchmaker_profile_assignments (matchmaker_id, profile_id, can_edit, can_view_contact, assigned_by) VALUES (?,?,1,1,?)', [u.matchmakerId, pid, u.id]);
    }
    return pid;
  });
  await audit(req, 'profile_created', 'profile', id);
  res.status(201).json({ id });
}));

router.get('/:id(\\d+)', wrap(async (req, res) => {
  const a = await getAccess(req.user, req.params.id);
  if (!a || (!a.canViewFull && !a.canViewPublic)) return res.status(404).json({ error: 'Not found' });
  if (a.canViewFull && !a.isOwner) await audit(req, 'profile_viewed_private', 'profile', a.profile.id, `level=${a.level}`);
  res.json(await buildProfileView(a, req.user));
}));

router.put('/:id(\\d+)', wrap(async (req, res) => {
  const a = await getAccess(req.user, req.params.id);
  if (!a || !a.canViewFull) return res.status(404).json({ error: 'Not found' });
  if (!a.canEdit) throw new HttpError(403, 'You are not allowed to edit this profile');
  const body = { ...(req.body || {}) };
  // Contact & address sections only if the caller may also see them.
  if (!a.canSeeContact) delete body.contact;
  if (!a.canSeeAddress) delete body.address;
  await tx(async (conn) => {
    await updateProfile(conn, a.profile.id, body);
    const publicKeys = ['display_name', 'public_city', 'public_education', 'public_occupation', 'public_bio', 'date_of_birth', 'gender'];
    const touchesPublic = body.basic && publicKeys.some((k) => k in body.basic);
    // Only edits to publicly shown fields send a live profile back for admin re-review.
    if (!a.isAdmin && a.profile.approval_status === 'approved' && touchesPublic) await conn.query("UPDATE profiles SET approval_status='pending' WHERE id=?", [a.profile.id]);
  });
  await audit(req, 'profile_updated', 'profile', a.profile.id);
  res.json({ ok: true });
}));

router.post('/:id(\\d+)/submit', wrap(async (req, res) => {
  const a = await getAccess(req.user, req.params.id);
  if (!a || !a.canViewFull) return res.status(404).json({ error: 'Not found' });
  if (!a.canEdit) throw new HttpError(403, 'Not allowed');
  if (!['draft', 'rejected'].includes(a.profile.approval_status)) throw new HttpError(400, 'Only drafts or rejected profiles can be submitted');
  await pool.query("UPDATE profiles SET approval_status='pending' WHERE id=?", [a.profile.id]);
  await audit(req, 'profile_submitted', 'profile', a.profile.id);
  res.json({ ok: true });
}));

router.post('/:id(\\d+)/review', requireRole('admin'), wrap(async (req, res) => {
  const { action, note } = req.body || {};
  const map = { approve: ['approval_status', 'approved'], reject: ['approval_status', 'rejected'], suspend: ['approval_status', 'suspended'], archive: ['approval_status', 'archived'], verify: ['verification_status', 'verified'], unverify: ['verification_status', 'unverified'] };
  if (!map[action]) throw new HttpError(400, 'Unknown action');
  const [[p]] = await pool.query('SELECT id, owner_user_id, created_by_user_id FROM profiles WHERE id=?', [req.params.id]);
  if (!p) throw new HttpError(404, 'Not found');
  const [col, val] = map[action];
  await pool.query(`UPDATE profiles SET ${col}=?, reviewed_by=?, reviewed_at=NOW() WHERE id=?`, [val, req.user.id, p.id]);
  if (note) await pool.query("INSERT INTO profile_internal_notes (profile_id, author_user_id, note_type, note) VALUES (?,?, 'admin', ?)", [p.id, req.user.id, String(note).slice(0, 2000)]);
  await notify(p.owner_user_id || p.created_by_user_id, 'profile_review', `Profile ${val}`, `Your profile status is now: ${val}.`);
  await audit(req, `profile_${action}`, 'profile', p.id, note);
  res.json({ ok: true });
}));

router.post('/:id(\\d+)/assign', requireRole('admin'), wrap(async (req, res) => {
  const { matchmaker_id, can_edit = true, can_view_contact = false } = req.body || {};
  const [[m]] = await pool.query("SELECT id, user_id FROM matchmakers WHERE id=? AND status='approved'", [matchmaker_id]);
  const [[p]] = await pool.query('SELECT id FROM profiles WHERE id=?', [req.params.id]);
  if (!m || !p) throw new HttpError(404, 'Matchmaker or profile not found');
  await pool.query(
    `INSERT INTO matchmaker_profile_assignments (matchmaker_id, profile_id, can_edit, can_view_contact, assigned_by) VALUES (?,?,?,?,?)
     ON DUPLICATE KEY UPDATE can_edit=VALUES(can_edit), can_view_contact=VALUES(can_view_contact)`,
    [m.id, p.id, can_edit ? 1 : 0, can_view_contact ? 1 : 0, req.user.id]);
  await notify(m.user_id, 'assignment', 'New profile assigned', `Profile #${p.id} was assigned to you.`);
  await audit(req, 'profile_assigned', 'profile', p.id, `matchmaker=${m.id} contact=${!!can_view_contact}`);
  res.json({ ok: true });
}));

router.delete('/:id(\\d+)/assign/:mid(\\d+)', requireRole('admin'), wrap(async (req, res) => {
  await pool.query('DELETE FROM matchmaker_profile_assignments WHERE profile_id=? AND matchmaker_id=?', [req.params.id, req.params.mid]);
  await audit(req, 'profile_unassigned', 'profile', Number(req.params.id), `matchmaker=${req.params.mid}`);
  res.json({ ok: true });
}));

router.post('/:id(\\d+)/notes', wrap(async (req, res) => {
  const a = await getAccess(req.user, req.params.id);
  if (!a || !(a.isAdmin || a.level === 'assigned')) return res.status(404).json({ error: 'Not found' });
  const note = String((req.body || {}).note || '').trim();
  if (!note || note.length > 2000) throw new ValidationError({ note: 'Enter a note (max 2000 characters)' });
  await pool.query('INSERT INTO profile_internal_notes (profile_id, author_user_id, note_type, note) VALUES (?,?,?,?)', [a.profile.id, req.user.id, a.isAdmin ? 'admin' : 'matchmaker', note]);
  res.status(201).json({ ok: true });
}));

// Compatibility indicators use only public card fields of the other profiles.
router.get('/:id(\\d+)/compatible', wrap(async (req, res) => {
  const a = await getAccess(req.user, req.params.id);
  if (!a || !a.canViewFull) return res.status(404).json({ error: 'Not found' });
  const [[pref]] = await pool.query('SELECT * FROM partner_preferences WHERE profile_id=?', [a.profile.id]);
  const opposite = a.profile.gender === 'male' ? 'female' : 'male';
  const [cands] = await pool.query("SELECT * FROM profiles WHERE approval_status='approved' AND visibility IN ('public','members') AND gender=? AND id<>? LIMIT 200", [opposite, a.profile.id]);
  const has = (hay, needle) => needle && hay && String(hay).toLowerCase().includes(String(needle).toLowerCase());
  const scored = cands.map((c) => {
    const age = ageFromDob(c.date_of_birth); let score = 0; const matched = []; let criteria = 0;
    if (pref && (pref.age_min || pref.age_max)) { criteria++; if (age >= (pref.age_min || 18) && age <= (pref.age_max || 90)) { score++; matched.push('age'); } }
    if (pref && pref.city_region) { criteria++; if (has(pref.city_region, c.public_city) || has(c.public_city, pref.city_region)) { score++; matched.push('city'); } }
    if (pref && pref.education) { criteria++; if (has(c.public_education, pref.education)) { score++; matched.push('education'); } }
    if (pref && pref.profession) { criteria++; if (has(c.public_occupation, pref.profession)) { score++; matched.push('profession'); } }
    if (pref && pref.marital_status) { criteria++; if (c.marital_status === pref.marital_status) { score++; matched.push('marital status'); } }
    return { ...publicCard(c), compatibility: criteria ? Math.round((score / criteria) * 100) : null, matched };
  }).sort((x, y) => (y.compatibility ?? -1) - (x.compatibility ?? -1)).slice(0, 30);
  res.json({ items: scored });
}));

router.post('/:id(\\d+)/report', wrap(async (req, res) => {
  const a = await getAccess(req.user, req.params.id);
  if (!a || !a.canViewPublic) return res.status(404).json({ error: 'Not found' });
  const reason = String((req.body || {}).reason || '').trim();
  if (reason.length < 5 || reason.length > 400) throw new ValidationError({ reason: 'Please describe the problem (5-400 characters)' });
  await pool.query('INSERT INTO abuse_reports (reporter_user_id, profile_id, reason) VALUES (?,?,?)', [req.user.id, a.profile.id, reason]);
  res.status(201).json({ ok: true });
}));

// ---------------------------------------------------------------- photos
const PHOTO_DIR = path.join(env.storageDir, 'photos');
fs.mkdirSync(PHOTO_DIR, { recursive: true });
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024, files: 1 } });

function sniff(buf) {
  if (buf.length > 12 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return { mime: 'image/jpeg', ext: 'jpg' };
  if (buf.length > 8 && buf.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return { mime: 'image/png', ext: 'png' };
  if (buf.length > 12 && buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WEBP') return { mime: 'image/webp', ext: 'webp' };
  return null;
}

router.post('/:id(\\d+)/photos', upload.single('photo'), wrap(async (req, res) => {
  const a = await getAccess(req.user, req.params.id);
  if (!a || !a.canViewFull) return res.status(404).json({ error: 'Not found' });
  if (!a.canEdit) throw new HttpError(403, 'Not allowed');
  if (!req.file) throw new HttpError(400, 'Choose an image file');
  const type = sniff(req.file.buffer); // real content check, the client-sent type is ignored
  if (!type) throw new HttpError(400, 'Only JPG, PNG or WEBP images are allowed');
  const [[{ n }]] = await pool.query('SELECT COUNT(*) n FROM profile_photos WHERE profile_id=?', [a.profile.id]);
  if (n >= 6) throw new HttpError(400, 'Maximum 6 photos per profile');
  const key = `${crypto.randomBytes(24).toString('hex')}.${type.ext}`;
  fs.writeFileSync(path.join(PHOTO_DIR, key), req.file.buffer, { mode: 0o600 });
  const [r] = await pool.query('INSERT INTO profile_photos (profile_id, storage_key, mime_type, size_bytes, is_main, uploaded_by) VALUES (?,?,?,?,?,?)', [a.profile.id, key, type.mime, req.file.size, n === 0 ? 1 : 0, req.user.id]);
  await audit(req, 'photo_uploaded', 'profile', a.profile.id);
  res.status(201).json({ id: r.insertId });
}));

router.delete('/:id(\\d+)/photos/:photoId(\\d+)', wrap(async (req, res) => {
  const a = await getAccess(req.user, req.params.id);
  if (!a || !a.canViewFull) return res.status(404).json({ error: 'Not found' });
  if (!a.canEdit) throw new HttpError(403, 'Not allowed');
  const [[ph]] = await pool.query('SELECT * FROM profile_photos WHERE id=? AND profile_id=?', [req.params.photoId, a.profile.id]);
  if (!ph) return res.status(404).json({ error: 'Not found' });
  await pool.query('DELETE FROM profile_photos WHERE id=?', [ph.id]);
  fs.rm(path.join(PHOTO_DIR, ph.storage_key), { force: true }, () => {});
  res.json({ ok: true });
}));

router.post('/:id(\\d+)/photos/:photoId(\\d+)/main', wrap(async (req, res) => {
  const a = await getAccess(req.user, req.params.id);
  if (!a || !a.canViewFull) return res.status(404).json({ error: 'Not found' });
  if (!a.canEdit) throw new HttpError(403, 'Not allowed');
  await pool.query('UPDATE profile_photos SET is_main = (id=?) WHERE profile_id=?', [req.params.photoId, a.profile.id]);
  res.json({ ok: true });
}));

// Protected retrieval: the file is streamed only after the same access check as the profile itself.
const photoRouter = require('express').Router();
photoRouter.get('/:photoId(\\d+)', requireAuth, wrap(async (req, res) => {
  const [[ph]] = await pool.query('SELECT * FROM profile_photos WHERE id=?', [req.params.photoId]);
  if (!ph) return res.status(404).json({ error: 'Not found' });
  const a = await getAccess(req.user, ph.profile_id);
  if (!a || !a.canSeePhotos) return res.status(404).json({ error: 'Not found' });
  if (!a.isOwner) await audit(req, 'photo_viewed', 'profile', ph.profile_id);
  res.set({ 'Content-Type': ph.mime_type, 'Cache-Control': 'private, max-age=300', 'X-Content-Type-Options': 'nosniff' });
  res.sendFile(path.join(PHOTO_DIR, ph.storage_key));
}));

module.exports = router;
module.exports.photoRouter = photoRouter;
