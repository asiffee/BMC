const router = require('express').Router();
const { pool } = require('../config/db');
const { wrap } = require('../middleware/errors');
const { requireRole } = require('../middleware/auth');

router.use(requireRole('matchmaker'));

// Statistics are computed only from the caller's own assigned profiles.
router.get('/dashboard', wrap(async (req, res) => {
  const mid = req.user.matchmakerId;
  const [byStatus] = await pool.query(
    `SELECT p.approval_status AS status, COUNT(*) AS count FROM matchmaker_profile_assignments a JOIN profiles p ON p.id=a.profile_id WHERE a.matchmaker_id=? GROUP BY p.approval_status`, [mid]);
  const [[req_]] = await pool.query(
    `SELECT COUNT(*) AS total, SUM(cr.status='pending') AS pending FROM contact_requests cr JOIN matchmaker_profile_assignments a ON a.profile_id=cr.to_profile_id WHERE a.matchmaker_id=?`, [mid]);
  const [intros] = await pool.query(
    `SELECT mi.id, mi.status, mi.profile_a_id, mi.profile_b_id, mi.created_at FROM match_introductions mi
     WHERE mi.profile_a_id IN (SELECT profile_id FROM matchmaker_profile_assignments WHERE matchmaker_id=?)
        OR mi.profile_b_id IN (SELECT profile_id FROM matchmaker_profile_assignments WHERE matchmaker_id=?) ORDER BY mi.id DESC LIMIT 20`, [mid, mid]);
  res.json({ profilesByStatus: byStatus, requests: { total: req_.total, pending: Number(req_.pending || 0) }, introductions: intros });
}));

module.exports = router;
