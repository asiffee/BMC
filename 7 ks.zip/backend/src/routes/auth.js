const router = require('express').Router();
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const rateLimit = require('express-rate-limit');
const { pool, tx } = require('../config/db');
const { wrap, HttpError } = require('../middleware/errors');
const { setSession, clearSession, requireAuth } = require('../middleware/auth');
const { audit } = require('../services/audit');
const { ValidationError, validatePassword } = require('../validators/schemas');

const testing = process.env.NODE_ENV === 'test';
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, skip: () => testing, message: { error: 'Too many attempts. Try again later.' } });
const regLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 20, skip: () => testing, message: { error: 'Too many attempts. Try again later.' } });
const sha = (t) => crypto.createHash('sha256').update(t).digest('hex');
const GENERIC = 'Incorrect email/phone or password';

const publicUser = (u) => ({ id: u.id, fullName: u.fullName, roles: u.roles, isAdmin: u.isAdmin, isMatchmaker: u.isMatchmaker });

router.post('/register', regLimiter, wrap(async (req, res) => {
  const b = req.body || {};
  const fields = {};
  const name = String(b.full_name || '').trim();
  const email = b.email ? String(b.email).trim().toLowerCase() : null;
  const phone = b.phone ? String(b.phone).trim() : null;
  if (name.length < 2 || name.length > 120) fields.full_name = 'Enter your full name';
  if (!email && !phone) fields.email = 'Email or phone is required';
  if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) fields.email = 'Invalid email';
  if (phone && !/^[0-9+\-\s]{7,20}$/.test(phone)) fields.phone = 'Invalid phone number';
  if (b.password !== b.confirm_password) fields.confirm_password = 'Passwords do not match';
  if (b.accept_terms !== true) fields.accept_terms = 'You must accept the privacy policy and terms';
  if (!['user', 'matchmaker'].includes(b.account_type || 'user')) fields.account_type = 'Invalid account type';
  try { validatePassword(b.password); } catch (e) { Object.assign(fields, e.fields); }
  if (Object.keys(fields).length) throw new ValidationError(fields);

  const hash = await bcrypt.hash(b.password, 12);
  try {
    await tx(async (conn) => {
      const [r] = await conn.query('INSERT INTO users (full_name, email, phone, password_hash, accepted_terms_at) VALUES (?,?,?,?,NOW())', [name, email, phone, hash]);
      const role = b.account_type === 'matchmaker' ? 'matchmaker' : 'user';
      await conn.query('INSERT INTO user_roles (user_id, role_id) SELECT ?, id FROM roles WHERE name=?', [r.insertId, role]);
      // Matchmakers start as "pending" and have no matchmaker powers until an admin approves them.
      if (role === 'matchmaker') await conn.query("INSERT INTO matchmakers (user_id, status) VALUES (?, 'pending')", [r.insertId]);
    });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') throw new ValidationError({ email: 'This email or phone is already registered' });
    throw e;
  }
  res.status(201).json({ ok: true, message: b.account_type === 'matchmaker' ? 'Account created. An administrator must approve your matchmaker access.' : 'Account created. Please log in.' });
}));

router.post('/login', loginLimiter, wrap(async (req, res) => {
  const id = String((req.body || {}).login || '').trim().toLowerCase();
  const pw = String((req.body || {}).password || '');
  const [[u]] = await pool.query('SELECT * FROM users WHERE email=? OR phone=?', [id, id]);
  const dummy = '$2a$12$C6UzMDM.H6dfI/f/IKcEeO5X3oXjD1wH0Q1Q2m3q4k5l6m7n8o9p0';
  const locked = u && u.locked_until && new Date(u.locked_until.replace(' ', 'T')) > new Date();
  const ok = await bcrypt.compare(pw, u ? u.password_hash : dummy);
  if (!u || locked || !ok || u.status !== 'active') {
    if (u && !ok) {
      await pool.query('UPDATE users SET failed_logins=failed_logins+1, locked_until=IF(failed_logins+1>=5, DATE_ADD(NOW(), INTERVAL 15 MINUTE), locked_until) WHERE id=?', [u.id]);
    }
    await audit({ ...req, user: null }, 'login_failed', 'user', u ? u.id : null, null);
    throw new HttpError(401, GENERIC);
  }
  await pool.query('UPDATE users SET failed_logins=0, locked_until=NULL, last_login_at=NOW() WHERE id=?', [u.id]);
  setSession(res, u.id);
  await audit({ ...req, user: { id: u.id } }, 'login', 'user', u.id, null);
  res.json({ ok: true });
}));

router.post('/logout', (req, res) => { clearSession(res); res.json({ ok: true }); });
router.get('/me', (req, res) => res.json({ user: req.user ? publicUser(req.user) : null }));

// No email service is configured: in development the reset link is printed in the server console.
router.post('/forgot-password', regLimiter, wrap(async (req, res) => {
  const id = String((req.body || {}).login || '').trim().toLowerCase();
  const [[u]] = await pool.query('SELECT id FROM users WHERE (email=? OR phone=?) AND status="active"', [id, id]);
  if (u) {
    const token = crypto.randomBytes(32).toString('hex');
    await pool.query('INSERT INTO password_reset_tokens (user_id, token_hash, expires_at) VALUES (?,?,DATE_ADD(NOW(), INTERVAL 1 HOUR))', [u.id, sha(token)]);
    if (process.env.NODE_ENV !== 'production') console.log(`[DEV] Password reset link: /reset-password?token=${token}`);
  }
  res.json({ ok: true, message: 'If the account exists, a reset link has been sent.' });
}));

router.post('/reset-password', regLimiter, wrap(async (req, res) => {
  const { token, password } = req.body || {};
  validatePassword(password);
  const [[t]] = await pool.query('SELECT * FROM password_reset_tokens WHERE token_hash=? AND used_at IS NULL AND expires_at > NOW()', [sha(String(token || ''))]);
  if (!t) throw new HttpError(400, 'This reset link is invalid or has expired');
  const hash = await bcrypt.hash(password, 12);
  await tx(async (conn) => {
    await conn.query('UPDATE users SET password_hash=?, failed_logins=0, locked_until=NULL WHERE id=?', [hash, t.user_id]);
    await conn.query('UPDATE password_reset_tokens SET used_at=NOW() WHERE id=?', [t.id]);
  });
  res.json({ ok: true });
}));

router.put('/password', requireAuth, wrap(async (req, res) => {
  const { current_password, new_password } = req.body || {};
  validatePassword(new_password);
  const [[u]] = await pool.query('SELECT password_hash FROM users WHERE id=?', [req.user.id]);
  if (!(await bcrypt.compare(String(current_password || ''), u.password_hash))) throw new HttpError(400, 'Current password is incorrect');
  await pool.query('UPDATE users SET password_hash=? WHERE id=?', [await bcrypt.hash(new_password, 12), req.user.id]);
  await audit(req, 'password_changed', 'user', req.user.id);
  res.json({ ok: true });
}));

router.post('/request-deletion', requireAuth, wrap(async (req, res) => {
  await pool.query("UPDATE users SET status='deletion_requested' WHERE id=? AND NOT EXISTS (SELECT 1 FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE ur.user_id=users.id AND r.name='admin')", [req.user.id]);
  await audit(req, 'deletion_requested', 'user', req.user.id);
  clearSession(res);
  res.json({ ok: true, message: 'Your request was received. An administrator will process it.' });
}));

module.exports = router;
