const router = require('express').Router();
const bcrypt = require('bcryptjs');
const { pool, tx } = require('../config/db');
const { wrap, HttpError } = require('../middleware/errors');
const { requireRole } = require('../middleware/auth');
const { audit } = require('../services/audit');
const { ValidationError, validatePassword, ageFromDob } = require('../validators/schemas');
const { profileCode } = require('../services/access');

router.use(requireRole('admin'));
const pg = (req) => { const p = Math.max(1, parseInt(req.query.page, 10) || 1); const l = Math.min(100, Math.max(1, parseInt(req.query.limit, 10) || 20)); return { p, l, off: (p - 1) * l }; };

router.get('/dashboard', wrap(async (_req, res) => {
  const [[c]] = await pool.query(`SELECT
    (SELECT COUNT(*) FROM profiles WHERE gender='male' AND approval_status<>'archived') male,
    (SELECT COUNT(*) FROM profiles WHERE gender='female' AND approval_status<>'archived') female,
    (SELECT COUNT(*) FROM users) users,
    (SELECT COUNT(*) FROM matchmakers WHERE status='approved') matchmakers,
    (SELECT COUNT(*) FROM profiles WHERE approval_status='pending') pending,
    (SELECT COUNT(*) FROM profiles WHERE verification_status='verified') verified,
    (SELECT COUNT(*) FROM profiles WHERE approval_status IN ('rejected','suspended')) rejected_suspended,
    (SELECT COUNT(*) FROM contact_inquiries WHERE status='new') inquiries,
    (SELECT COUNT(*) FROM abuse_reports WHERE status='open') reports`);
  const [recent] = await pool.query('SELECT id, full_name, created_at FROM users ORDER BY id DESC LIMIT 8');
  const [monthly] = await pool.query("SELECT DATE_FORMAT(created_at,'%Y-%m') AS month, COUNT(*) AS registrations FROM users WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH) GROUP BY month ORDER BY month");
  res.json({ counts: c, recentRegistrations: recent, monthly });
}));

router.get('/users', wrap(async (req, res) => {
  const { p, l, off } = pg(req); const args = []; let w = '';
  if (req.query.q) { w = 'WHERE u.full_name LIKE ? OR u.email LIKE ?'; args.push(`%${req.query.q}%`, `%${req.query.q}%`); }
  const [[{ total }]] = await pool.query(`SELECT COUNT(*) total FROM users u ${w}`, args);
  const [rows] = await pool.query(
    `SELECT u.id, u.full_name, u.email, u.phone, u.status, u.created_at, GROUP_CONCAT(r.name) roles
     FROM users u LEFT JOIN user_roles ur ON ur.user_id=u.id LEFT JOIN roles r ON r.id=ur.role_id ${w} GROUP BY u.id ORDER BY u.id DESC LIMIT ? OFFSET ?`, [...args, l, off]);
  res.json({ items: rows, page: p, limit: l, total });
}));

router.patch('/users/:id(\\d+)', wrap(async (req, res) => {
  const status = (req.body || {}).status;
  if (!['active', 'suspended', 'deactivated'].includes(status)) throw new ValidationError({ status: 'Invalid status' });
  if (Number(req.params.id) === req.user.id) throw new HttpError(400, 'You cannot change your own account');
  await pool.query('UPDATE users SET status=? WHERE id=?', [status, req.params.id]);
  await audit(req, 'user_status_changed', 'user', Number(req.params.id), status);
  res.json({ ok: true });
}));

router.get('/matchmakers', wrap(async (_req, res) => {
  const [rows] = await pool.query(
    `SELECT m.id, m.status, m.business_name, u.full_name, u.email, u.phone,
     (SELECT COUNT(*) FROM matchmaker_profile_assignments a WHERE a.matchmaker_id=m.id) AS profiles
     FROM matchmakers m JOIN users u ON u.id=m.user_id ORDER BY m.id DESC`);
  res.json({ items: rows });
}));

router.post('/matchmakers', wrap(async (req, res) => {
  const b = req.body || {};
  const name = String(b.full_name || '').trim(); const email = String(b.email || '').trim().toLowerCase();
  if (name.length < 2 || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new ValidationError({ full_name: 'Name and valid email are required' });
  validatePassword(b.password);
  const hash = await bcrypt.hash(b.password, 12);
  try {
    const id = await tx(async (conn) => {
      const [r] = await conn.query('INSERT INTO users (full_name, email, phone, password_hash, accepted_terms_at) VALUES (?,?,?,?,NOW())', [name, email, b.phone || null, hash]);
      await conn.query("INSERT INTO user_roles (user_id, role_id) SELECT ?, id FROM roles WHERE name='matchmaker'", [r.insertId]);
      await conn.query("INSERT INTO matchmakers (user_id, business_name, status, approved_by) VALUES (?,?, 'approved', ?)", [r.insertId, b.business_name || null, req.user.id]);
      return r.insertId;
    });
    await audit(req, 'matchmaker_created', 'user', id);
    res.status(201).json({ id });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') throw new ValidationError({ email: 'Email or phone already exists' });
    throw e;
  }
}));

router.patch('/matchmakers/:id(\\d+)', wrap(async (req, res) => {
  const status = (req.body || {}).status;
  if (!['approved', 'suspended', 'pending'].includes(status)) throw new ValidationError({ status: 'Invalid status' });
  await pool.query('UPDATE matchmakers SET status=?, approved_by=? WHERE id=?', [status, req.user.id, req.params.id]);
  await audit(req, 'matchmaker_status_changed', 'matchmaker', Number(req.params.id), status);
  res.json({ ok: true });
}));

router.get('/inquiries', wrap(async (req, res) => {
  const { p, l, off } = pg(req);
  const [[{ total }]] = await pool.query('SELECT COUNT(*) total FROM contact_inquiries');
  const [rows] = await pool.query('SELECT id, full_name, email_or_phone, subject, message, status, created_at FROM contact_inquiries ORDER BY id DESC LIMIT ? OFFSET ?', [l, off]);
  res.json({ items: rows, page: p, limit: l, total });
}));
router.patch('/inquiries/:id(\\d+)', wrap(async (req, res) => {
  const status = (req.body || {}).status;
  if (!['new', 'read', 'answered', 'spam'].includes(status)) throw new ValidationError({ status: 'Invalid status' });
  await pool.query('UPDATE contact_inquiries SET status=? WHERE id=?', [status, req.params.id]);
  res.json({ ok: true });
}));

router.get('/reports', wrap(async (_req, res) => {
  const [rows] = await pool.query('SELECT id, profile_id, reason, status, created_at FROM abuse_reports ORDER BY id DESC LIMIT 100');
  res.json({ items: rows });
}));

router.get('/audit-logs', wrap(async (req, res) => {
  const { p, l, off } = pg(req);
  const [[{ total }]] = await pool.query('SELECT COUNT(*) total FROM audit_logs');
  const [rows] = await pool.query('SELECT a.id, a.action, a.entity_type, a.entity_id, a.detail, a.created_at, u.full_name AS actor FROM audit_logs a LEFT JOIN users u ON u.id=a.actor_user_id ORDER BY a.id DESC LIMIT ? OFFSET ?', [l, off]);
  res.json({ items: rows, page: p, limit: l, total });
}));

const SETTING_KEYS = ['contact_person', 'contact_phone', 'contact_whatsapp', 'contact_email', 'office_address', 'business_hours', 'hero_title', 'hero_text', 'carousel', 'developer_photo'];
router.get('/settings', wrap(async (_req, res) => {
  const [rows] = await pool.query('SELECT setting_key k, setting_value v FROM website_settings');
  const out = {}; rows.forEach((r) => { out[r.k] = r.v; });
  res.json(out);
}));
router.put('/settings', wrap(async (req, res) => {
  const body = req.body || {};
  for (const k of Object.keys(body)) {
    if (!SETTING_KEYS.includes(k)) continue;
    await pool.query('INSERT INTO website_settings (setting_key, setting_value, updated_by) VALUES (?,?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value), updated_by=VALUES(updated_by)', [k, String(body[k]).slice(0, 5000), req.user.id]);
  }
  await audit(req, 'settings_updated', 'settings', null, Object.keys(body).join(','));
  res.json({ ok: true });
}));

// CSV opens directly in Excel. Cells starting with = + - @ are neutralised (CSV formula injection).
const cell = (v) => { let s = v === null || v === undefined ? '' : String(v); if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`; return `"${s.replace(/"/g, '""')}"`; };
router.get('/export/profiles.csv', wrap(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT p.*, c.primary_phone, c.email AS contact_email, a.city AS addr_city, a.permanent_address
     FROM profiles p LEFT JOIN profile_contacts c ON c.profile_id=p.id LEFT JOIN profile_addresses a ON a.profile_id=p.id ORDER BY p.id`);
  const head = ['Profile ID', 'Name', 'Gender', 'Age', 'Marital status', 'City', 'Status', 'Verification', 'Phone', 'Email', 'Address'];
  const lines = [head.map(cell).join(',')];
  rows.forEach((p) => lines.push([profileCode(p.id), p.full_name, p.gender, ageFromDob(p.date_of_birth), p.marital_status, p.public_city, p.approval_status, p.verification_status, p.primary_phone, p.contact_email, p.permanent_address].map(cell).join(',')));
  await audit(req, 'export_profiles', 'profile', null, `${rows.length} rows`);
  res.set({ 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="bandhan-profiles.csv"' });
  res.send(`\uFEFF${lines.join('\r\n')}`);
}));

module.exports = router;
