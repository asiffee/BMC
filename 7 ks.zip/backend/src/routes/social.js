const router = require('express').Router();
const { pool, tx } = require('../config/db');
const { wrap, HttpError } = require('../middleware/errors');
const { requireAuth } = require('../middleware/auth');
const { getAccess, publicCard } = require('../services/access');
const { audit, notify } = require('../services/audit');
const { ValidationError } = require('../validators/schemas');

router.use(requireAuth);

// ---------------------------------------------------------------- favorites
router.get('/favorites', wrap(async (req, res) => {
  const [rows] = await pool.query("SELECT p.* FROM profile_favorites f JOIN profiles p ON p.id=f.profile_id WHERE f.user_id=? AND p.approval_status='approved' ORDER BY f.created_at DESC", [req.user.id]);
  res.json({ items: rows.map(publicCard) });
}));
router.post('/favorites/:id(\\d+)', wrap(async (req, res) => {
  const a = await getAccess(req.user, req.params.id);
  if (!a || !a.canViewPublic) return res.status(404).json({ error: 'Not found' });
  await pool.query('INSERT IGNORE INTO profile_favorites (user_id, profile_id) VALUES (?,?)', [req.user.id, a.profile.id]);
  res.json({ ok: true });
}));
router.delete('/favorites/:id(\\d+)', wrap(async (req, res) => {
  await pool.query('DELETE FROM profile_favorites WHERE user_id=? AND profile_id=?', [req.user.id, req.params.id]);
  res.json({ ok: true });
}));

// ---------------------------------------------------------------- contact requests
// Accepting a request never reveals phone numbers or addresses: an administrator mediates the introduction.
router.post('/contact-requests', wrap(async (req, res) => {
  const { to_profile_id, message } = req.body || {};
  const a = await getAccess(req.user, to_profile_id);
  if (!a || !a.canViewPublic) throw new HttpError(404, 'Profile not found');
  if (a.isOwner) throw new HttpError(400, 'You cannot send a request to your own profile');
  const msg = message ? String(message).trim().slice(0, 500) : null;
  const [[mine]] = await pool.query('SELECT id FROM profiles WHERE owner_user_id=?', [req.user.id]);
  try {
    const [r] = await pool.query('INSERT INTO contact_requests (from_user_id, from_profile_id, to_profile_id, message) VALUES (?,?,?,?)', [req.user.id, mine ? mine.id : null, a.profile.id, msg]);
    await notify(a.profile.owner_user_id || a.profile.created_by_user_id, 'contact_request', 'New contact request', 'Someone is interested in your profile.');
    await audit(req, 'contact_request_sent', 'profile', a.profile.id);
    res.status(201).json({ id: r.insertId });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'You already sent a request to this profile');
    throw e;
  }
}));

router.get('/contact-requests', wrap(async (req, res) => {
  const [sent] = await pool.query(
    `SELECT cr.id, cr.status, cr.message, cr.created_at, p.id AS profile_id, p.display_name, p.public_city
     FROM contact_requests cr JOIN profiles p ON p.id=cr.to_profile_id WHERE cr.from_user_id=? ORDER BY cr.id DESC`, [req.user.id]);
  const [received] = await pool.query(
    `SELECT cr.id, cr.status, cr.message, cr.created_at, fp.id AS from_profile_id, fp.display_name AS from_display_name, fp.public_city AS from_city
     FROM contact_requests cr JOIN profiles tp ON tp.id=cr.to_profile_id LEFT JOIN profiles fp ON fp.id=cr.from_profile_id
     WHERE tp.owner_user_id=? ORDER BY cr.id DESC`, [req.user.id]);
  res.json({ sent, received });
}));

router.put('/contact-requests/:id(\\d+)', wrap(async (req, res) => {
  const status = (req.body || {}).status;
  if (!['accepted', 'declined'].includes(status)) throw new ValidationError({ status: 'Choose accepted or declined' });
  const [[cr]] = await pool.query('SELECT * FROM contact_requests WHERE id=?', [req.params.id]);
  if (!cr) throw new HttpError(404, 'Not found');
  const a = await getAccess(req.user, cr.to_profile_id);
  const mayRespond = a && (a.isOwner || a.isAdmin || (a.level === 'assigned' && a.canEdit));
  if (!mayRespond) throw new HttpError(404, 'Not found');
  if (cr.status !== 'pending') throw new HttpError(400, 'This request was already answered');
  await tx(async (conn) => {
    await conn.query('UPDATE contact_requests SET status=?, responded_at=NOW() WHERE id=?', [status, cr.id]);
    if (status === 'accepted' && cr.from_profile_id) {
      const [lo, hi] = [Math.min(cr.from_profile_id, cr.to_profile_id), Math.max(cr.from_profile_id, cr.to_profile_id)];
      await conn.query("INSERT IGNORE INTO match_introductions (profile_a_id, profile_b_id, introduced_by, contact_request_id, status) VALUES (?,?,?,?, 'accepted')", [lo, hi, req.user.id, cr.id]);
    }
    await notify(cr.from_user_id, 'contact_response', `Your request was ${status}`, status === 'accepted' ? 'An administrator will arrange the introduction.' : null, conn);
  });
  await audit(req, `contact_request_${status}`, 'contact_request', cr.id);
  res.json({ ok: true });
}));

// ---------------------------------------------------------------- notifications
router.get('/notifications', wrap(async (req, res) => {
  const [rows] = await pool.query('SELECT id, type, title, body, read_at, created_at FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 50', [req.user.id]);
  res.json({ items: rows });
}));
router.post('/notifications/:id(\\d+)/read', wrap(async (req, res) => {
  await pool.query('UPDATE notifications SET read_at=NOW() WHERE id=? AND user_id=?', [req.params.id, req.user.id]);
  res.json({ ok: true });
}));

module.exports = router;
