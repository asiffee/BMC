const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

function notFound(_req, res) { res.status(404).json({ error: 'Not found' }); }

// eslint-disable-next-line no-unused-vars
function errorHandler(err, _req, res, _next) {
  if (err.status === 400 && err.fields) return res.status(400).json({ error: 'Please correct the highlighted fields', fields: err.fields });
  if (err.status && err.status < 500) return res.status(err.status).json({ error: err.message });
  if (err.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: 'File is too large (max 5 MB)' });
  console.error('[server error]', err.code || '', err.message); // never log request bodies
  res.status(500).json({ error: 'Something went wrong' });
}

class HttpError extends Error { constructor(status, message) { super(message); this.status = status; } }
module.exports = { wrap, notFound, errorHandler, HttpError };
