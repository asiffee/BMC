const jwt = require('jsonwebtoken');
const env = require('../config/env');
const { pool } = require('../config/db');

const COOKIE = 'bmc_token';

function setSession(res, userId) {
  const token = jwt.sign({ sub: userId }, env.jwtSecret, { expiresIn: '8h' });
  res.cookie(COOKIE, token, { httpOnly: true, sameSite: 'lax', secure: env.cookieSecure, maxAge: 8 * 3600 * 1000 });
}
const clearSession = (res) => res.clearCookie(COOKIE);

// Loads the user fresh from the database on every request, so roles and
// suspensions take effect immediately and the client can never claim a role.
async function authenticate(req, _res, next) {
  req.user = null;
  const token = req.cookies && req.cookies[COOKIE];
  if (!token) return next();
  try {
    const { sub } = jwt.verify(token, env.jwtSecret);
    const [[u]] = await pool.query('SELECT id, full_name, email, phone, status FROM users WHERE id=?', [sub]);
    if (!u || u.status !== 'active') return next();
    const [roles] = await pool.query('SELECT r.name FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE ur.user_id=?', [u.id]);
    const names = roles.map((r) => r.name);
    const [[mm]] = await pool.query("SELECT id FROM matchmakers WHERE user_id=? AND status='approved'", [u.id]);
    req.user = {
      id: u.id, fullName: u.full_name, email: u.email, phone: u.phone, roles: names,
      isAdmin: names.includes('admin'),
      isMatchmaker: names.includes('matchmaker') && !!mm,
      matchmakerId: mm ? mm.id : null,
    };
  } catch (_e) { /* invalid or expired token -> anonymous */ }
  next();
}

// Cookies are SameSite=Lax; this custom header additionally blocks cross-site form posts.
function csrfGuard(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  if (req.get('x-requested-with') !== 'BMC') return res.status(403).json({ error: 'Blocked request' });
  next();
}

const requireAuth = (req, res, next) => (req.user ? next() : res.status(401).json({ error: 'Please log in' }));
const requireRole = (...roles) => (req, res, next) => {
  if (!req.user) return res.status(401).json({ error: 'Please log in' });
  const ok = roles.some((r) => (r === 'admin' ? req.user.isAdmin : r === 'matchmaker' ? req.user.isMatchmaker : req.user.roles.includes(r)));
  return ok ? next() : res.status(403).json({ error: 'Access denied' });
};

module.exports = { authenticate, csrfGuard, requireAuth, requireRole, setSession, clearSession };
