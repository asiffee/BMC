const env = require('./config/env');
const app = require('./app');
app.listen(env.port, () => console.log(`Bandhan API running on http://localhost:${env.port}`));
