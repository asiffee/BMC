// The ONE place that decides who may see or edit a profile, and what each
// audience receives. Every route uses these helpers - nothing is "hidden in CSS".
const { pool } = require('../config/db');
const { ageFromDob } = require('../validators/schemas');

const profileCode = (id) => `BMC-${String(id).padStart(6, '0')}`;

function publicCard(p) {
  return {
    id: p.id,
    code: profileCode(p.id),
    displayName: p.display_name,
    gender: p.gender,
    age: ageFromDob(p.date_of_birth),
    education: p.public_education,
    occupation: p.public_occupation,
    city: p.public_city,
    bio: p.public_bio,
    verified: p.verification_status === 'verified',
  };
}

async function getAccess(user, profileId) {
  const [[p]] = await pool.query('SELECT * FROM profiles WHERE id=?', [profileId]);
  if (!p) return null;
  const a = {
    profile: p, level: 'none', isAdmin: false, isOwner: false, assignment: null,
    canViewFull: false, canEdit: false, canSeeContact: false, canSeeAddress: false, canSeePhotos: false, canViewPublic: false,
  };
  const approved = p.approval_status === 'approved';
  if (approved && p.visibility === 'public') a.canViewPublic = true;
  if (approved && p.visibility === 'members' && user) a.canViewPublic = true;

  if (user && user.isAdmin) {
    Object.assign(a, { level: 'admin', isAdmin: true, canViewFull: true, canEdit: true, canSeeContact: true, canSeeAddress: true, canSeePhotos: true, canViewPublic: true });
  } else if (user && p.owner_user_id === user.id) {
    Object.assign(a, { level: 'owner', isOwner: true, canViewFull: true, canEdit: true, canSeeContact: true, canSeeAddress: true, canSeePhotos: true, canViewPublic: true });
  } else if (user && user.isMatchmaker) {
    const [[as]] = await pool.query('SELECT * FROM matchmaker_profile_assignments WHERE matchmaker_id=? AND profile_id=?', [user.matchmakerId, p.id]);
    if (as) {
      Object.assign(a, {
        level: 'assigned', assignment: as, canViewFull: true, canEdit: !!as.can_edit,
        canSeeContact: !!as.can_view_contact, canSeeAddress: !!as.can_view_contact, canSeePhotos: true, canViewPublic: true,
      });
    }
  }
  return a;
}

// Shape a profile for the caller. Sections are only queried when allowed.
async function buildProfileView(a, user) {
  const p = a.profile;
  if (!a.canViewFull) return { ...publicCard(p), access: 'public' };
  const {
    reviewed_by: _r, owner_user_id: _o, created_by_user_id: _c, ...basic
  } = p;
  const out = { id: p.id, code: profileCode(p.id), access: a.level, basic: { ...basic, age: ageFromDob(p.date_of_birth) }, permissions: {
    canEdit: a.canEdit, canSeeContact: a.canSeeContact, canSeeAddress: a.canSeeAddress, canReview: a.isAdmin,
  } };
  const one = async (t) => (await pool.query(`SELECT * FROM ${t} WHERE profile_id=?`, [p.id]))[0][0] || null;
  out.family = await one('profile_family');
  out.employment = await one('profile_employment');
  out.preferences = await one('partner_preferences');
  [out.education] = await pool.query('SELECT id, level, degree_title, field_of_study, institution, graduation_year, is_highest, notes FROM profile_education WHERE profile_id=?', [p.id]);
  if (a.canSeeAddress) out.address = await one('profile_addresses');
  if (a.canSeeContact) out.contact = await one('profile_contacts');
  if (a.canSeePhotos) {
    [out.photos] = await pool.query('SELECT id, is_main FROM profile_photos WHERE profile_id=? ORDER BY is_main DESC, id', [p.id]); // ids only, never storage keys
  }
  if (a.isAdmin) {
    [out.internalNotes] = await pool.query('SELECT id, note_type, note, created_at FROM profile_internal_notes WHERE profile_id=? ORDER BY id DESC', [p.id]);
  } else if (a.level === 'assigned') {
    [out.internalNotes] = await pool.query("SELECT id, note_type, note, created_at FROM profile_internal_notes WHERE profile_id=? AND author_user_id=? ORDER BY id DESC", [p.id, user.id]);
  }
  return out;
}

// Row shape for list screens of people allowed to see names.
const listRow = (p) => ({
  id: p.id, code: profileCode(p.id), fullName: p.full_name, displayName: p.display_name, gender: p.gender,
  age: ageFromDob(p.date_of_birth), city: p.public_city, status: p.approval_status,
  verification: p.verification_status, visibility: p.visibility, createdAt: p.created_at,
});

module.exports = { getAccess, buildProfileView, publicCard, listRow, profileCode };
