const crypto = require('crypto');
const env = require('../config/env');
const { pool } = require('../config/db');

const ipHash = (req) => crypto.createHash('sha256').update(`${req.ip || ''}${env.jwtSecret}`).digest('hex');

async function audit(req, action, entityType, entityId, detail, conn = pool) {
  try {
    await conn.query(
      'INSERT INTO audit_logs (actor_user_id, action, entity_type, entity_id, detail, ip_hash) VALUES (?,?,?,?,?,?)',
      [req.user ? req.user.id : null, action, entityType || null, entityId || null, detail ? String(detail).slice(0, 500) : null, ipHash(req)]
    );
  } catch (e) { console.error('[audit failed]', e.message); }
}

async function notify(userId, type, title, body, conn = pool) {
  if (!userId) return;
  await conn.query('INSERT INTO notifications (user_id, type, title, body) VALUES (?,?,?,?)', [userId, type, title, body || null]);
}

module.exports = { audit, notify, ipHash };
