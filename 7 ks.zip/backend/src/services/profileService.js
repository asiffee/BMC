const { clean, BASIC, ADDRESS, CONTACT, EMPLOYMENT, FAMILY, PREFS, EDUCATION_ROW, ValidationError, ageFromDob } = require('../validators/schemas');

async function upsert(conn, table, profileId, data) {
  const cols = Object.keys(data);
  if (!cols.length) return;
  await conn.query(
    `INSERT INTO ${table} (profile_id, ${cols.join(',')}) VALUES (?, ${cols.map(() => '?').join(',')})
     ON DUPLICATE KEY UPDATE ${cols.map((c) => `${c}=VALUES(${c})`).join(',')}`,
    [profileId, ...cols.map((c) => data[c])]
  );
}

function checkAge(dob) {
  const age = ageFromDob(dob);
  if (age < 18 || age > 90) throw new ValidationError({ date_of_birth: 'Age must be between 18 and 90' });
}

// Validate everything first, then write inside the caller's transaction.
function prepare(body, { partial }) {
  const out = {};
  let fields = {};
  try { out.basic = clean(BASIC, body.basic, { partial }); } catch (e) {
    if (!(e instanceof ValidationError)) throw e;
    fields = e.fields;
  }
  const dob = body.basic && body.basic.date_of_birth;
  if (typeof dob === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(dob) && !fields.date_of_birth) {
    try { checkAge(dob); } catch (e) { Object.assign(fields, e.fields); }
  }
  if (Object.keys(fields).length) throw new ValidationError(fields);
  if (body.address !== undefined) out.address = clean(ADDRESS, body.address, { partial: true });
  if (body.contact !== undefined) out.contact = clean(CONTACT, body.contact, { partial: true });
  if (body.employment !== undefined) out.employment = clean(EMPLOYMENT, body.employment, { partial: true });
  if (body.family !== undefined) out.family = clean(FAMILY, body.family, { partial: true });
  if (body.preferences !== undefined) out.preferences = clean(PREFS, body.preferences, { partial: true });
  if (body.education !== undefined) {
    if (!Array.isArray(body.education) || body.education.length > 12) throw new ValidationError({ education: 'Provide up to 12 entries' });
    out.education = body.education.map((row) => clean(EDUCATION_ROW, row));
  }
  return out;
}

async function writeSections(conn, profileId, v) {
  if (v.address) await upsert(conn, 'profile_addresses', profileId, v.address);
  if (v.contact) await upsert(conn, 'profile_contacts', profileId, v.contact);
  if (v.employment) await upsert(conn, 'profile_employment', profileId, v.employment);
  if (v.family) await upsert(conn, 'profile_family', profileId, v.family);
  if (v.preferences) await upsert(conn, 'partner_preferences', profileId, v.preferences);
  if (v.education) {
    await conn.query('DELETE FROM profile_education WHERE profile_id=?', [profileId]);
    for (const r of v.education) {
      await conn.query(
        'INSERT INTO profile_education (profile_id, level, degree_title, field_of_study, institution, graduation_year, is_highest, notes) VALUES (?,?,?,?,?,?,?,?)',
        [profileId, r.level, r.degree_title ?? null, r.field_of_study ?? null, r.institution ?? null, r.graduation_year ?? null, r.is_highest ?? 0, r.notes ?? null]
      );
    }
  }
}

async function createProfile(conn, { creatorId, ownerId, body }) {
  const v = prepare(body, { partial: false });
  const cols = Object.keys(v.basic);
  const [r] = await conn.query(
    `INSERT INTO profiles (owner_user_id, created_by_user_id, ${cols.join(',')}) VALUES (?, ?, ${cols.map(() => '?').join(',')})`,
    [ownerId || null, creatorId, ...cols.map((c) => v.basic[c])]
  );
  await writeSections(conn, r.insertId, v);
  await conn.query("INSERT INTO profile_consents (profile_id, consent_type, granted, granted_by) VALUES (?, 'data_collection', 1, ?)", [r.insertId, creatorId]);
  return r.insertId;
}

async function updateProfile(conn, profileId, body) {
  const v = prepare(body, { partial: true });
  const cols = Object.keys(v.basic);
  if (cols.length) await conn.query(`UPDATE profiles SET ${cols.map((c) => `${c}=?`).join(',')} WHERE id=?`, [...cols.map((c) => v.basic[c]), profileId]);
  await writeSections(conn, profileId, v);
}

module.exports = { createProfile, updateProfile };
