const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '..', '..', '.env') });

const env = {
  nodeEnv: process.env.NODE_ENV || 'development',
  port: Number(process.env.PORT || 5000),
  clientOrigin: process.env.CLIENT_ORIGIN || 'http://localhost:5173',
  jwtSecret: process.env.JWT_SECRET || '',
  cookieSecure: process.env.COOKIE_SECURE === 'true',
  storageDir: path.resolve(process.env.STORAGE_DIR || path.join(__dirname, '..', '..', '..', 'storage', 'private')),
  db: {
    host: process.env.DB_HOST || 'localhost',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'bandhan_marriage_consultant',
  },
};

if (env.jwtSecret.length < 32) {
  throw new Error('JWT_SECRET is missing or too short (use at least 32 random characters). Check your .env file.');
}
module.exports = env;
