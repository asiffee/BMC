const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const env = require('./config/env');
const { authenticate, csrfGuard } = require('./middleware/auth');
const { notFound, errorHandler } = require('./middleware/errors');

const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(helmet());
app.use(cors({ origin: env.clientOrigin, credentials: true }));
app.use(express.json({ limit: '200kb' }));
app.use(cookieParser());
app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, limit: 600, skip: () => env.nodeEnv === 'test' }));
app.use('/api', csrfGuard, authenticate);

app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.use('/api/auth', require('./routes/auth'));
app.use('/api/public', require('./routes/public'));
const profiles = require('./routes/profiles');
app.use('/api/profiles', profiles);
app.use('/api/photos', profiles.photoRouter);
app.use('/api', require('./routes/social'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api/matchmaker', require('./routes/matchmaker'));

app.use(notFound);
app.use(errorHandler);
module.exports = app;
